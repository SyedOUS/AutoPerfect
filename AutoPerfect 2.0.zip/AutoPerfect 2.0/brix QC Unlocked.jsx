// Illustrator QC Script — robust bounds, persistent QC user, optimized HTML generation
// Saves a QC HTML report with improved artboard/bounds detection and a cached QC username.
// NOTE: All in-document highlighting (fillColor/strokeColor) has been removed.

if (app.documents.length === 0) {
    alert("No document open.");
} else {
    var doc = app.activeDocument;
    var docName = doc.name.replace(/\.ai$/i, '');

    // ---------- QC USER CACHE (persistent per system) ----------
    var qcUser = "";
    try {
        var configFile = new File(Folder.userData + "/Illustrator_QC_User.txt");

        // load cached name if exists
        if (configFile.exists) {
            try {
                configFile.open("r");
                qcUser = configFile.read();
                configFile.close();
            } catch (e) { qcUser = ""; }
        }

        // if no cached user, ask once
        if (!qcUser || qcUser.replace(/\s+/g, "").length === 0) {
            qcUser = prompt("Enter your QC Name (will be saved to this machine):", "");
            if (!qcUser || qcUser.replace(/\s+/g, "").length === 0) {
                qcUser = "Unknown QC User";
            }
            // save to file
            try {
                configFile.open("w");
                configFile.encoding = "UTF-8";
                configFile.write(qcUser);
                configFile.close();
            } catch (err) {
                // non-fatal: just continue
            }
        }
    } catch (e) {
        qcUser = "Unknown QC User";
    }

    qcUser = String(qcUser);

    // Get folder where document is saved
    var docFolder = null;
    try { docFolder = doc.path; } catch (e) { alert("Document not saved. Report will be saved to Desktop."); docFolder = Folder.desktop; }

    // ---------- Helpers (robust) ----------
    // Normalize a rect and return [left,top,right,bottom] as numbers, fixed ordering
    function normalizeRect(rect) {
        if (!rect || rect.length !== 4) return [0, 0, 0, 0];
        var L = parseFloat(rect[0]);
        var T = parseFloat(rect[1]);
        var R = parseFloat(rect[2]);
        var B = parseFloat(rect[3]);
        if (!isFinite(L) || !isFinite(T) || !isFinite(R) || !isFinite(B)) return [0, 0, 0, 0];
        var left = Math.min(L, R);
        var right = Math.max(L, R);
        var top = Math.max(T, B);
        var bottom = Math.min(T, B);
        return [left, top, right, bottom];
    }

    // robust overlap area between two rects (each [l,t,r,b])
    function overlapArea(rectA, rectB) {
        try {
            var a = normalizeRect(rectA);
            var b = normalizeRect(rectB);
            var left = Math.max(a[0], b[0]);
            var right = Math.min(a[2], b[2]);
            var top = Math.min(a[1], b[1]);
            var bottom = Math.max(a[3], b[3]);
            var w = right - left;
            var h = top - bottom;
            if (!isFinite(w) || !isFinite(h) || w <= 0 || h <= 0) return 0;
            return w * h;
        } catch (e) {
            return 0;
        }
    }

    // safer findBestArtboardForBounds: returns artboard index or -1
    function findBestArtboardForBounds(bounds) {
        var bestIndex = -1, bestArea = 0;
        try {
            var nb = normalizeRect(bounds);
            // degenerate bounds -> can't compute proper overlap
            if ((nb[2] - nb[0]) <= 0 || (nb[1] - nb[3]) <= 0) {
                // try center-point fallback below
            }
            for (var a = 0; a < doc.artboards.length; a++) {
                try {
                    var ar = normalizeRect(doc.artboards[a].artboardRect);
                    var area = overlapArea(nb, ar);
                    if (area > bestArea) { bestArea = area; bestIndex = a; }
                } catch (ie) { /* continue */ }
            }
            // if no positive overlap and bounds degenerate, try center-point heuristic
            if (bestIndex === -1 && doc.artboards.length > 0) {
                // compute center of bounds (if degenerate this will still be a number)
                var cx = (nb[0] + nb[2]) / 2;
                var cy = (nb[1] + nb[3]) / 2;
                for (var ai = 0; ai < doc.artboards.length; ai++) {
                    try {
                        var ar2 = normalizeRect(doc.artboards[ai].artboardRect);
                        if (cx >= ar2[0] && cx <= ar2[2] && cy <= ar2[1] && cy >= ar2[3]) {
                            bestIndex = ai;
                            break;
                        }
                    } catch (ex) {}
                }
            }
        } catch (e) {}
        return bestIndex;
    }

    // robust isOutside using normalized rects, with tiny tolerance
    function isOutside(bounds, artRect) {
        var b = normalizeRect(bounds);
        var a = normalizeRect(artRect);
        // degenerate artRect -> treat as outside to be safe
        if ((a[2] - a[0]) <= 0 || (a[1] - a[3]) <= 0) return true;
        var tol = 0.0001;
        if (b[0] < a[0] - tol || b[2] > a[2] + tol || b[1] > a[1] + tol || b[3] < a[3] - tol) return true;
        return false;
    }

    // html escape
    function htmlEscape(str) {
        if (str === undefined || str === null) return "";
        str = String(str);
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
                  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }

    // render double spaces (keeps as before)
    function renderDoubleSpaces(raw) {
        try {
            raw = raw === undefined || raw === null ? "" : String(raw);
            var out = "";
            var lastIndex = 0;
            var re = / {2,}/g;
            var m;
            while ((m = re.exec(raw)) !== null) {
                var start = m.index;
                var len = m[0].length;
                if (start > lastIndex) out += htmlEscape(raw.substring(lastIndex, start));
                var nbspRun = "";
                for (var k = 0; k < len; k++) nbspRun += "&nbsp;";
                out += '<span class="ds-highlight">' + nbspRun + '</span>';
                out += '<small class="ds-pos">pos:' + start + '</small>';
                lastIndex = start + len;
            }
            if (lastIndex < raw.length) out += htmlEscape(raw.substring(lastIndex));
            if (out === "") return htmlEscape(raw);
            return out;
        } catch (err) {
            try { return htmlEscape(raw); } catch (e) { return ""; }
        }
    }

    // ---------- Data structures ----------
    var artboardsData = [];
    for (var a = 0; a < doc.artboards.length; a++) {
        artboardsData.push({
            name: doc.artboards[a].name || ("Artboard " + (a + 1)),
            index: a,
            fontIssues: [], doubleSpaceIssues: [], smallFontIssues: [], strokeIssues: [], outsideIssues: [], hasIssues: false
        });
    }

    var outsideAll = {
        name: "Outside All Artboards",
        fontIssues: [], doubleSpaceIssues: [], smallFontIssues: [], strokeIssues: [], outsideIssues: [], hasIssues: false
    };

    var globalSwatchIssues = [];

    // ---------- Collect issues: textFrames (character-level decimal detection) ----------
    for (var i = 0; i < doc.textFrames.length; i++) {
        try {
            var tf = doc.textFrames[i];
            if (tf.locked || tf.hidden) continue;

            var rawText = (tf.contents || "").toString();
            var bounds = tf.visibleBounds;
            var nbounds = normalizeRect(bounds);
            var artIndex = findBestArtboardForBounds(bounds);
            var artData = (artIndex === -1) ? outsideAll : artboardsData[artIndex];
            var currentArtboardRect = (artIndex === -1) ? null : doc.artboards[artIndex].artboardRect;

            // Attempt character-level inspection
            var runs = []; // { startIdx, endIdx, size }
            try {
                var chars = tf.characters;
                var runStart = -1;
                var runSize = null;
                for (var c = 0; c < chars.length; c++) {
                    var chSize;
                    try {
                        chSize = chars[c].characterAttributes.size;
                    } catch (ce) {
                        chSize = tf.textRange.characterAttributes.size;
                    }
                    if (typeof chSize === "number" && (Math.abs(chSize % 1) > 0.000001)) {
                        if (runStart === -1) {
                            runStart = c;
                            runSize = chSize;
                        }
                    } else {
                        if (runStart !== -1) {
                            runs.push({ startIdx: runStart, endIdx: c - 1, size: runSize });
                            runStart = -1;
                            runSize = null;
                        }
                    }
                }
                if (runStart !== -1) {
                    runs.push({ startIdx: runStart, endIdx: chars.length - 1, size: runSize });
                }
            } catch (eChars) {
                // characters[] not accessible — fallback to frame-level
                try {
                    var frameSize = tf.textRange.characterAttributes.size;
                    if (typeof frameSize === "number" && (Math.abs(frameSize % 1) > 0.000001)) {
                        runs.push({ startIdx: 0, endIdx: rawText.length - 1, size: frameSize });
                    }
                } catch (ef) {
                    // can't detect
                }
            }

            // For each run, expand to a word and save sentence+word
            for (var r = 0; r < runs.length; r++) {
                try {
                    var run = runs[r];
                    var sIdx = run.startIdx;
                    var eIdx = run.endIdx;

                    if (sIdx < 0) sIdx = 0;
                    if (eIdx < sIdx) eIdx = sIdx;
                    if (sIdx >= rawText.length) sIdx = rawText.length - 1;
                    if (eIdx >= rawText.length) eIdx = rawText.length - 1;
                    if (sIdx < 0) sIdx = 0;
                    if (eIdx < 0) eIdx = 0;

                    // Find word boundaries around sIdx..eIdx
                    var leftBound = -1;
                    for (var L = sIdx - 1; L >= 0; L--) {
                        var ch = rawText.charAt(L);
                        if (ch === ' ' || ch === '\n' || ch === '\t' || ch === '\r') { leftBound = L; break; }
                    }
                    var wordStart = (leftBound === -1) ? 0 : leftBound + 1;

                    var rightBound = -1;
                    for (var R = eIdx + 1; R < rawText.length; R++) {
                        var ch2 = rawText.charAt(R);
                        if (ch2 === ' ' || ch2 === '\n' || ch2 === '\t' || ch2 === '\r') { rightBound = R; break; }
                    }
                    var wordEnd = (rightBound === -1) ? rawText.length : rightBound;

                    var word = rawText.substring(wordStart, wordEnd);
                    word = (word || "").replace(/^\s+|\s+$/g, "");
                    var sentence = rawText;

                    artData.fontIssues.push({ sentence: sentence, word: word, size: run.size !== undefined ? run.size.toFixed(2) : "" });

                    artData.hasIssues = true;
                    // NOTE: highlight removed — no in-document color changes
                } catch (errRun) { /* continue */ }
            }

            // Keep double-space & small font checks (frame-level)
            try {
                if (tf.contents && tf.contents.match(/ {2,}/)) {
                    artData.doubleSpaceIssues.push({ name: tf.contents || "(empty)" });
                    artData.hasIssues = true;
                }
            } catch (e) {}

            try {
                var fsize = tf.textRange.characterAttributes.size;
                if (typeof fsize === "number" && fsize < 8) {
                    artData.smallFontIssues.push({ name: tf.contents || "(empty)", size: fsize.toFixed(2) });
                    artData.hasIssues = true;
                }
            } catch (e) {}

            // outside-artboard flags (use robust isOutside)
            if (artIndex === -1) {
                // if bounds degenerate, try center-point fallback to avoid false outside
                var nb = normalizeRect(bounds);
                if ((nb[2] - nb[0]) <= 0 || (nb[1] - nb[3]) <= 0) {
                    // try center-point artboard assignment
                    var cx = (nb[0] + nb[2]) / 2;
                    var cy = (nb[1] + nb[3]) / 2;
                    var foundIndex = -1;
                    for (var ai = 0; ai < doc.artboards.length; ai++) {
                        var ar = normalizeRect(doc.artboards[ai].artboardRect);
                        if (cx >= ar[0] && cx <= ar[2] && cy <= ar[1] && cy >= ar[3]) { foundIndex = ai; break; }
                    }
                    if (foundIndex !== -1) {
                        artIndex = foundIndex;
                        artData = artboardsData[artIndex];
                        currentArtboardRect = doc.artboards[artIndex].artboardRect;
                    } else {
                        artData.outsideIssues.push({ type: "TextFrame (no overlap)" });
                        artData.hasIssues = true;
                        // NOTE: highlight removed
                    }
                } else {
                    artData.outsideIssues.push({ type: "TextFrame (no overlap)" });
                    artData.hasIssues = true;
                    // NOTE: highlight removed
                }
            } else {
                if (isOutside(bounds, currentArtboardRect)) {
                    artData.outsideIssues.push({ type: "TextFrame" });
                    artData.hasIssues = true;
                    // NOTE: highlight removed
                }
            }
        } catch (e) { /* ignore single item error */ }
    }

    // ---------- Collect issues: pageItems ----------
    for (var j = 0; j < doc.pageItems.length; j++) {
        try {
            var it = doc.pageItems[j];
            if (it.locked || it.hidden || it.guides || it.typename === "TextFrame") continue;
            var boundsIt = it.visibleBounds;
            var nboundsIt = normalizeRect(boundsIt);
            var artIndexIt = findBestArtboardForBounds(boundsIt);
            var artDataIt = (artIndexIt === -1) ? outsideAll : artboardsData[artIndexIt];
            var curArtRect = (artIndexIt === -1) ? null : doc.artboards[artIndexIt].artboardRect;

            if (it.stroked) {
                var sw = it.strokeWidth;
                if (!isValidStrokeWidth(sw)) {
                    artDataIt.strokeIssues.push({ type: it.typename, width: sw.toFixed(2) });
                    artDataIt.hasIssues = true;
                    // NOTE: highlight removed
                }
            }

            if (artIndexIt === -1) {
                // degenerate bounds -> try center-point fallback
                if ((nboundsIt[2] - nboundsIt[0]) <= 0 || (nboundsIt[1] - nboundsIt[3]) <= 0) {
                    var cx2 = (nboundsIt[0] + nboundsIt[2]) / 2;
                    var cy2 = (nboundsIt[1] + nboundsIt[3]) / 2;
                    var foundIndex2 = -1;
                    for (var ai2 = 0; ai2 < doc.artboards.length; ai2++) {
                        var ar3 = normalizeRect(doc.artboards[ai2].artboardRect);
                        if (cx2 >= ar3[0] && cx2 <= ar3[2] && cy2 <= ar3[1] && cy2 >= ar3[3]) { foundIndex2 = ai2; break; }
                    }
                    if (foundIndex2 !== -1) {
                        artIndexIt = foundIndex2;
                        artDataIt = artboardsData[artIndexIt];
                        curArtRect = doc.artboards[artIndexIt].artboardRect;
                    } else {
                        artDataIt.outsideIssues.push({ type: it.typename + " (no overlap)" });
                        artDataIt.hasIssues = true;
                        // NOTE: highlight removed
                    }
                } else {
                    artDataIt.outsideIssues.push({ type: it.typename + " (no overlap)" });
                    artDataIt.hasIssues = true;
                    // NOTE: highlight removed
                }
            } else {
                if (isOutside(boundsIt, curArtRect)) {
                    artDataIt.outsideIssues.push({ type: it.typename });
                    artDataIt.hasIssues = true;
                    // NOTE: highlight removed
                }
            }
        } catch (e) { /* ignore item error */ }
    }

    // ---------- Swatches ----------
    for (var s = 0; s < doc.swatches.length; s++) {
        try { if (isBadSwatch(doc.swatches[s])) globalSwatchIssues.push({ name: doc.swatches[s].name, index: s + 1 }); } catch (e) {}
    }
    // optional: alert swatch issues (disabled by default)
    // if (globalSwatchIssues.length > 0) { ... }

    // ---------- Build HTML (fast: push to array, join once) ----------
    var parts = [];

    // Minimal but pastel-styled CSS (kept your palette)
    parts.push('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">');
    parts.push('<title>Illustrator QC Report: ' + htmlEscape(docName) + '</title><style>');
    parts.push(':root{--bg:#f5f7fb;--panel:#fff;--muted:#707a83;--border:#e6e9ee;--primary:#6C5CE7;--secondary:#00B894}');
    parts.push('html,body{margin:0;padding:0;background:var(--bg);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial;color:#1f2933;}');
    parts.push('.container{max-width:980px;margin:20px auto;padding:18px}.header h1{margin:0;color:var(--primary);font-size:2rem}.meta{color:var(--muted);font-size:0.9rem;margin-top:6px}');
    parts.push('.summary{display:flex;gap:10px;margin:14px 0;flex-wrap:wrap}.stat{background:var(--panel);border:1px solid var(--border);padding:8px;border-radius:10px;min-width:120px}');
    parts.push('.stat .num{font-weight:700}.artboard-section{background:var(--panel);border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:12px}');
    parts.push('.artboard-title{display:flex;justify-content:space-between;align-items:center}.badges{display:flex;gap:8px}.badge{padding:5px 8px;border-radius:999px;border:1px solid var(--border);font-size:0.85rem;background:linear-gradient(90deg, rgba(0,0,0,0.02), rgba(255,255,255,0.01))}');
    parts.push('ul{margin:8px 0 0;padding:0;list-style:none;display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px}li{background:var(--bg);padding:8px;border-radius:6px;border:1px solid var(--border);font-size:0.95rem}');
    parts.push('.ds-highlight{background:#cfe9ff;padding:2px 6px;border-radius:4px;font-weight:700;font-family:monospace}.ds-pos{margin-left:6px;font-size:0.75rem;color:var(--muted)}');
    parts.push('</style></head><body><div class="container">');
    parts.push('<div class="header"><h1>Brix QC Report  — ' + htmlEscape(docName) + '</h1>');
    parts.push('<div class="meta"><strong>Scan Date:</strong> ' + (new Date()).toString() +
           ' &nbsp;|&nbsp; <strong>QC Person:</strong> ' + htmlEscape(qcUser) +
           '</div></div>');

    // counts
    var totalArtboards = artboardsData.length;
    var artboardsWithIssues = 0;
    for (var t = 0; t < artboardsData.length; t++) if (artboardsData[t].hasIssues) artboardsWithIssues++;
    var swatchIssueCount = globalSwatchIssues.length;

    parts.push('<div class="summary">');
    parts.push('<div class="stat"><div class="num">' + totalArtboards + '</div><div class="label">Total artboards</div></div>');
    parts.push('<div class="stat"><div class="num">' + artboardsWithIssues + '</div><div class="label">Artboards with issues</div></div>');
    parts.push('<div class="stat"><div class="num">' + swatchIssueCount + '</div><div class="label">Swatch issues</div></div>');
    parts.push('</div>');

    // swatch block
    parts.push('<div class="artboard-section"><div class="artboard-title"><h2>Global Swatch Naming Issues</h2><div class="badges"><span class="badge">' + swatchIssueCount + ' issues</span></div></div>');
    if (!globalSwatchIssues || globalSwatchIssues.length === 0) {
        parts.push('<div style="color:green;font-style:italic">All swatches properly named.</div>');
    } else {
        parts.push('<ul>');
        for (var si2 = 0; si2 < globalSwatchIssues.length; si2++) {
            parts.push('<li><strong>' + (si2 + 1) + '. ' + htmlEscape(globalSwatchIssues[si2].name) + '</strong><br><small>Panel: ' + globalSwatchIssues[si2].index + '</small></li>');
        }
        parts.push('</ul>');
    }
    parts.push('</div>');

    // artboards sections (only artboards with issues)
    for (var ai = 0; ai < artboardsData.length; ai++) {
        var data = artboardsData[ai];
        if (!data || !data.hasIssues) continue;
        parts.push('<div class="artboard-section"><div class="artboard-title"><h2>Artboard: ' + htmlEscape(data.name) + '</h2>');
        var fC = data.fontIssues.length, dC = data.doubleSpaceIssues.length, sC = data.smallFontIssues.length, stC = data.strokeIssues.length, oC = data.outsideIssues.length;
        parts.push('<div class="badges"><span class="badge">' + fC + ' fonts</span><span class="badge">' + dC + ' doubles</span><span class="badge">' + sC + ' small</span><span class="badge">' + stC + ' strokes</span><span class="badge">' + oC + ' outside</span></div></div>');

        parts.push('<div style="margin-top:8px;">');

        // Font issues
        parts.push('<h4 style="margin:6px 0 4px;color:#d9534f">Decimal Font Sizes <span class="badge">' + fC + '</span></h4>');
        if (fC === 0) parts.push('<div class="meta">None</div>'); else {
            parts.push('<ul>');
            for (var fi = 0; fi < data.fontIssues.length; fi++) {
                var isf = data.fontIssues[fi];
                var sentence = (isf.sentence || "").toString();
                var word = (isf.word || "").toString();
                var displaySentence = "";
                if (sentence.length) {
                    var idx = -1;
                    if (word.length) {
                        idx = sentence.toLowerCase().indexOf(word.toLowerCase());
                    }
                    if (idx === -1 && word.length) {
                        idx = sentence.indexOf(word);
                    }
                    if (idx !== -1 && word.length) {
                        var before = sentence.substring(0, idx);
                        var match = sentence.substring(idx, idx + word.length);
                        var after = sentence.substring(idx + word.length);
                        displaySentence = htmlEscape(before) + '<span style="color:#d9534f;font-weight:700">' + htmlEscape(match) + '</span>' + htmlEscape(after);
                    } else {
                        displaySentence = htmlEscape(sentence);
                    }
                } else if (word.length) {
                    displaySentence = '<span style="color:#d9534f;font-weight:700">' + htmlEscape(word) + '</span>';
                } else {
                    displaySentence = "(unknown)";
                }

                parts.push('<li><strong>' + (fi+1) + '. </strong>' + displaySentence + '<br><small>' + (isf.size || '') + ' pt</small></li>');
            }
            parts.push('</ul>');
        }

        // Double spaces
        parts.push('<h4 style="margin:6px 0 4px;color:#3498db">Double Spaces <span class="badge">' + dC + '</span></h4>');
        if (dC === 0) parts.push('<div class="meta">None</div>'); else {
            parts.push('<ul>');
            for (var di = 0; di < data.doubleSpaceIssues.length; di++) {
                var ds = data.doubleSpaceIssues[di];
                var raw = ds.name || '';
                var displayRaw = raw.length > 1800 ? raw.substring(0,1797) + '...' : raw;
                parts.push('<li><strong>' + (di+1) + '. </strong><span>' + renderDoubleSpaces(displayRaw) + '</span></li>');
            }
            parts.push('</ul>');
        }

        // Small fonts
        parts.push('<h4 style="margin:6px 0 4px;color:#ffb84d">Small Fonts (<8) <span class="badge">' + sC + '</span></h4>');
        if (sC === 0) parts.push('<div class="meta">None</div>'); else {
            parts.push('<ul>');
            for (var si3 = 0; si3 < data.smallFontIssues.length; si3++) {
                var sf = data.smallFontIssues[si3];
                parts.push('<li><strong>' + (si3+1) + '. ' + htmlEscape(sf.name.length > 120 ? sf.name.substring(0,117)+'...' : sf.name) + '</strong><br><small>' + (sf.size||'') + ' pt</small></li>');
            }
            parts.push('</ul>');
        }

        // Stroke issues
        parts.push('<h4 style="margin:6px 0 4px;color:#ffb84d">Stroke Issues <span class="badge">' + stC + '</span></h4>');
        if (stC === 0) parts.push('<div class="meta">None</div>'); else {
            parts.push('<ul>');
            for (var sti = 0; sti < data.strokeIssues.length; sti++) {
                var st = data.strokeIssues[sti];
                parts.push('<li><strong>' + (sti+1) + '. ' + htmlEscape(st.type) + '</strong><br><small>' + (st.width||'') + ' pt</small></li>');
            }
            parts.push('</ul>');
        }

        // Outside issues
        parts.push('<h4 style="margin:6px 0 4px;color:#b254ff">Outside Artboard <span class="badge">' + oC + '</span></h4>');
        if (oC === 0) parts.push('<div class="meta">None</div>'); else {
            parts.push('<ul>');
            for (var oi = 0; oi < data.outsideIssues.length; oi++) {
                var oitem = data.outsideIssues[oi];
                parts.push('<li><strong>' + (oi+1) + '. ' + htmlEscape(oitem.type) + '</strong></li>');
            }
            parts.push('</ul>');
        }

        parts.push('</div></div>'); // close artboard section
    }

    // Outside all artboards
    if (outsideAll && outsideAll.hasIssues) {
        parts.push('<div class="artboard-section"><div class="artboard-title"><h2>' + htmlEscape(outsideAll.name) + '</h2>');
        var oaF = outsideAll.fontIssues.length, oaD = outsideAll.doubleSpaceIssues.length, oaS = outsideAll.smallFontIssues.length, oaSt = outsideAll.strokeIssues.length, oaO = outsideAll.outsideIssues.length;
        parts.push('<div class="badges"><span class="badge">' + oaF + ' fonts</span><span class="badge">' + oaD + ' doubles</span><span class="badge">' + oaS + ' small</span><span class="badge">' + oaO + ' outside</span></div></div>');
        parts.push('<div style="margin-top:8px;"><h4 style="color:#b254ff">Outside All Artboards <span class="badge">' + oaO + '</span></h4>');
        if (oaO === 0) parts.push('<div class="meta">None</div>'); else {
            parts.push('<ul>');
            for (var oii = 0; oii < outsideAll.outsideIssues.length; oii++) {
                parts.push('<li><strong>' + (oii+1) + '. ' + htmlEscape(outsideAll.outsideIssues[oii].type) + '</strong></li>');
            }
            parts.push('</ul>');
        }
        parts.push('</div></div>');
    }

    // footer
    parts.push('<div style="margin-top:12px;color:var(--muted);font-size:0.9rem">Generated by Illustrator QC Script</div>');
    parts.push('</div></body></html>');

    var reportContent = parts.join('');

    // Save file
    try {
        var reportFileName = docName + '_QC_Report.html';
        var reportFile = new File(docFolder + '/' + reportFileName);
        reportFile.encoding = 'UTF-8';
        if (reportFile.open('w')) {
            reportFile.write(reportContent);
            reportFile.close();
            try { if (reportFile.exists) reportFile.execute(); } catch (e) {}
            alert('QC Report saved: ' + reportFile.fsName);
        } else {
            alert('Unable to open report file for writing.');
        }
    } catch (err) {
        alert('Error saving QC Report: ' + err.message);
    }
}

// ---------- small helper used earlier ----------
function isValidStrokeWidth(width) {
    var r = Math.round(width * 100) / 100 % 1;
    r = Math.round(r * 100) / 100;
    return (r === 0 || r === 0.5 || r === 0.75);
}

function isBadSwatch(sw) {
    try {
        var n = sw.name.toLowerCase();
        if (n == "[none]" || n == "[registration]" || n == "[black]" || n == "[paper]") return false;
        return (n.match(/^new swatch/i) || n.match(/^swatch/i) || n.match(/^c=\d+\s*m=\d+\s*y=\d+\s*k=\d+/i) ||
            n.match(/^r=\d+\s*g=\d+\s*b=\d+/i) || n.match(/^gray=/i) || n.match(/^#/));
    } catch (ee) { return false; }
}
