/*
brixSmartRenditions_FINAL_CLEAN_v2_CORE_FAST.jsx
---------------------------------------------------------
✔ Empty text cleanup
✔ MD cleanup + crop
✔ Stable per-character font rounding
✔ Stroke snapping on ALL artboards
✔ Renditions (SM / L / XL) created correctly
✔ Optimized for speed
*/

#target illustrator
#targetengine "brixSmartRenditions_v2_CORE_FAST"

(function () {

    if (app.documents.length === 0) return;

    var doc = app.activeDocument;

    var AB_NAMES = ["SM", "MD", "L", "XL"];
    var MIN_FONT = { SM: 8, MD: 10, L: 12, XL: 12 };

    //==================================================
    // HELPERS
    //==================================================

    function rectObj(r) {
        return {
            left: r[0], top: r[1], right: r[2], bottom: r[3],
            width: Math.abs(r[2] - r[0]),
            height: Math.abs(r[1] - r[3])
        };
    }

    function getAB(name) {
        for (var i = 0; i < doc.artboards.length; i++) {
            if (doc.artboards[i].name === name) return doc.artboards[i];
        }
        return null;
    }

    function collectTextFrames(container, arr) {
        arr = arr || [];
        try { for (var i = 0; i < container.textFrames.length; i++) arr.push(container.textFrames[i]); } catch (e) {}
        try { for (var g = 0; g < container.groupItems.length; g++) collectTextFrames(container.groupItems[g], arr); } catch (e) {}
        return arr;
    }

    function collectPathItems(container, arr) {
        arr = arr || [];
        try { for (var i = 0; i < container.pathItems.length; i++) arr.push(container.pathItems[i]); } catch (e) {}
        try { for (var g = 0; g < container.groupItems.length; g++) collectPathItems(container.groupItems[g], arr); } catch (e) {}
        return arr;
    }

    function snapStroke(sw) {
        sw = Number(sw) || 0;
        if (sw < 1) {
            if (sw < 0.375) return 0.25;
            if (sw < 0.625) return 0.5;
            return 0.75;
        }
        return Math.round(sw);
    }

    function forceTextRefresh(tf) {
        try {
            var ch = tf.textRange.characters;
            if (ch.length) {
                var s = ch[0].characterAttributes.size;
                ch[0].characterAttributes.size = s + 0.01;
                ch[0].characterAttributes.size = s;
            }
        } catch (e) {}
    }

    //==================================================
    // PRECHECK
    //==================================================

    for (var i = 0; i < AB_NAMES.length; i++) {
        if (!getAB(AB_NAMES[i])) return;
        try { doc.layers.getByName(AB_NAMES[i]); }
        catch (e) { doc.layers.add().name = AB_NAMES[i]; }
    }

    //==================================================
    // EMPTY TEXT FRAME CLEANUP
    //==================================================

    try {
        for (var t = doc.textFrames.length - 1; t >= 0; t--) {
            try {
                var tf = doc.textFrames[t];
                var raw = String(tf.contents || "")
                    .replace(/\u00A0/g, " ")
                    .replace(/[\t\r\n]/g, " ")
                    .replace(/\s+/g, " ")
                    .replace(/^\s+|\s+$/g, "");
                if (raw.length === 0) tf.remove();
            } catch (e) {}
        }
    } catch (e) {}

    //==================================================
    // CLEAN MD
    //==================================================

    (function cleanMD() {

        var mdLayer = doc.layers.getByName("MD");
        var mdText = collectTextFrames(mdLayer, []);

        // space cleanup + font rounding
        for (var i = 0; i < mdText.length; i++) {
            try {
                var tf = mdText[i];
                forceTextRefresh(tf);

                var ch = tf.textRange.characters;
                var x = 0;

                while (x < ch.length - 1) {
                    if (ch[x].contents === " " && ch[x + 1].contents === " ") {
                        ch[x + 1].remove();
                        ch = tf.textRange.characters;
                        continue;
                    }
                    x++;
                }

                while (ch.length && ch[0].contents === " ") ch[0].remove();
                while (ch.length && ch[ch.length - 1].contents === " ") ch[ch.length - 1].remove();

                for (var c = 0; c < ch.length; c++) {
                    var ns = Math.round(Number(ch[c].characterAttributes.size) || 0);
                    if (ns < MIN_FONT.MD) ns = MIN_FONT.MD;
                    ch[c].characterAttributes.size = ns;
                }

            } catch (e) {}
        }

        // stroke snap (MD)
        var mdPaths = collectPathItems(mdLayer, []);
        for (var p = 0; p < mdPaths.length; p++) {
            try { mdPaths[p].strokeWidth = snapStroke(mdPaths[p].strokeWidth); } catch (e) {}
        }

        // move to top + crop artboard
        try {
            var mdAB = getAB("MD");
            var r = rectObj(mdAB.artboardRect);
            var items = mdLayer.pageItems;

            if (items.length) {
                var top = -1e9, bottom = 1e9;

                for (var k = 0; k < items.length; k++) {
                    var vb = items[k].visibleBounds;
                    if (vb[1] > top) top = vb[1];
                    if (vb[3] < bottom) bottom = vb[3];
                }

                var dy = r.top - top;
                for (var m = 0; m < items.length; m++) {
                    items[m].translate(0, dy);
                }

                mdAB.artboardRect = [
                    r.left,
                    r.top,
                    r.right,
                    r.top - Math.abs((top + dy) - (bottom + dy))
                ];
            }
        } catch (e) {}

    })();

    //==================================================
    // RENDITIONS: SM / L / XL
    //==================================================

    var mdLayer = doc.layers.getByName("MD");
    var mdRect = rectObj(getAB("MD").artboardRect);
    var mdWidth = mdRect.width;

    var targets = ["SM", "L", "XL"];

    for (var t = 0; t < targets.length; t++) {

        var name = targets[t];
        var tLayer = doc.layers.getByName(name);
        var tAB = getAB(name);
        var r = rectObj(tAB.artboardRect);

        var scale = r.width / mdWidth;
        var grp = tLayer.groupItems.add();

        for (var i = 0; i < mdLayer.pageItems.length; i++) {
            mdLayer.pageItems[i].duplicate(grp, ElementPlacement.PLACEATEND);
        }

        grp.resize(scale * 100, scale * 100, true, true, true, true, scale * 100);

        // font rounding
        var dText = collectTextFrames(grp, []);
        for (var i = 0; i < dText.length; i++) {
            try {
                forceTextRefresh(dText[i]);
                var ch = dText[i].textRange.characters;
                for (var c = 0; c < ch.length; c++) {
                    var ns = Math.round(Number(ch[c].characterAttributes.size) || 0);
                    if (ns < MIN_FONT[name]) ns = MIN_FONT[name];
                    ch[c].characterAttributes.size = ns;
                }
            } catch (e) {}
        }

        // stroke snap
        var dPaths = collectPathItems(grp, []);
        for (var p = 0; p < dPaths.length; p++) {
            dPaths[p].strokeWidth = snapStroke(dPaths[p].strokeWidth);
        }

        // align + crop
        var vb = grp.visibleBounds;
        grp.translate(
            (r.left + r.width / 2) - ((vb[0] + vb[2]) / 2),
            r.top - vb[1]
        );

        var vb2 = grp.visibleBounds;
        tAB.artboardRect = [
            r.left,
            r.top,
            r.left + r.width,
            r.top - Math.abs(vb2[1] - vb2[3])
        ];
    }

    // DONE
})();