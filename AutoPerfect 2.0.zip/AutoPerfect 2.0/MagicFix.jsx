/*
AutoPerfect - Minimal, robust cleanup + move+crop
Refactor of previous AutoPerfect_MoveCrop script — compact and safer.
Back up your file before running.
*/

#target illustrator
#targetengine "AutoPerfect_MoveCrop"

(function () {
    if (app.documents.length === 0) { alert("No document open."); return; }
    var doc = app.activeDocument;

    // MIN FONT per artboard-layer name (uppercase)
    var MIN_FONT = { SM: 8, MD: 10, L: 12, XL: 12 };

    // ---------- Utilities ----------
    function safe(fn) { try { return fn(); } catch (e) { return null; } }

    function rectObj(r) {
        return { left: r[0], top: r[1], right: r[2], bottom: r[3],
                 width: Math.abs(r[2] - r[0]), height: Math.abs(r[1] - r[3]) };
    }

    function collectTextFrames(container) {
        var out = [];
        safe(function () {
            for (var i = 0; i < container.textFrames.length; i++) out.push(container.textFrames[i]);
            for (var g = 0; g < container.groupItems.length; g++) out = out.concat(collectTextFrames(container.groupItems[g]));
        });
        return out;
    }

    function collectPathItems(container) {
        var out = [];
        safe(function () {
            for (var i = 0; i < container.pathItems.length; i++) out.push(container.pathItems[i]);
            for (var g = 0; g < container.groupItems.length; g++) out = out.concat(collectPathItems(container.groupItems[g]));
        });
        return out;
    }

    function enableScaleCorners() {
        var cmds = ["scaleCorners", "ScaleCorners", "Scale Corners", "Scale Corner"];
        for (var i = 0; i < cmds.length; i++) safe(function(){ app.executeMenuCommand(cmds[i]); });
        safe(function(){
            if (app.preferences && typeof app.preferences.setBooleanPreference === 'function')
                app.preferences.setBooleanPreference('scaleCorners', true);
        });
    }

    function isEmptyTextFrame(tf) {
        var raw = String(tf.contents || "");
        raw = raw.replace(/\u00A0/g, " ").replace(/[\t\r\n]/g, " ");
        raw = raw.replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
        return raw.length === 0;
    }

    function snapStrokeWidth(sw) {
        sw = Number(sw) || 0;
        if (sw < 1) {
            if (sw < 0.375) return 0.25;
            if (sw < 0.625) return 0.5;
            return 0.75;
        }
        return Math.round(sw);
    }

    // Custom rounding rule: frac < 0.6 => floor, else ceil
    function customRoundSize(n, min) {
        n = Number(n) || 0;
        if (n < min) return min;
        var intPart = Math.floor(n);
        var frac = n - intPart;
        if (frac === 0) return n; // already integer
        return (frac < 0.6) ? intPart : intPart + 1;
    }

    // ---------- 0) Enable scale-corners
    enableScaleCorners();

    // ---------- 1) Remove empty text frames globally (safe)
    try {
        for (var ti = doc.textFrames.length - 1; ti >= 0; ti--) {
            var tf = doc.textFrames[ti];
            if (!tf) continue;
            if (tf.locked) continue;
            try { if (!tf.layer.visible) continue; } catch(e){}
            if (isEmptyTextFrame(tf)) safe(function(){ tf.remove(); });
        }
    } catch (e) {}

    // ---------- 2) Per-artboard: cleanup then move+crop ----------
    for (var ai = 0; ai < doc.artboards.length; ai++) {
        var ab = safe((function(i){ return function(){ return doc.artboards[i]; }; })(ai));
        if (!ab) continue;
        var abName = String(ab.name || "").toUpperCase();

        // Find matching layer by name; fallback to same index
        var layer = null;
        try { layer = doc.layers.getByName(ab.name); } catch (e) { try { layer = doc.layers[ai]; } catch (ee) { layer = null; } }
        if (!layer) continue;

        // A) collapse double spaces & trim per textframe (character-level) — preserves style runs
        var tfs = collectTextFrames(layer);
        for (var ti2 = 0; ti2 < tfs.length; ti2++) {
            var tfc = tfs[ti2];
            if (!tfc || !tfc.contents) continue;
            var chars = null;
            try { chars = tfc.textRange.characters; } catch(e){ chars = null; }
            if (!chars) continue;

            // collapse consecutive spaces
            var idx = 0;
            while (idx < chars.length - 1) {
                try {
                    if (chars[idx].contents === " " && chars[idx+1].contents === " ") {
                        chars[idx+1].remove();
                        chars = tfc.textRange.characters; // refresh
                        continue;
                    }
                } catch (e) { break; }
                idx++;
            }
            // trim leading
            while (chars.length > 0 && chars[0].contents === " ") { try { chars[0].remove(); chars = tfc.textRange.characters; } catch(e){ break; } }
            // trim trailing
            while (chars.length > 0 && chars[chars.length-1].contents === " ") { try { chars[chars.length-1].remove(); chars = tfc.textRange.characters; } catch(e){ break; } }
        }

        // B) per-character font enforcement + rounding (preserve mixed runs)
        var minForLayer = MIN_FONT[abName] !== undefined ? MIN_FONT[abName] : 8;
        var tfs2 = collectTextFrames(layer);
        for (var t2 = 0; t2 < tfs2.length; t2++) {
            var tf2 = tfs2[t2];
            if (!tf2) continue;
            var chars2 = null;
            try { chars2 = tf2.textRange.characters; } catch(e){ chars2 = null; }
            if (!chars2) continue;
            for (var c = 0; c < chars2.length; c++) {
                try {
                    var ch = chars2[c];
                    var chSize = Number(ch.characterAttributes.size) || 0;
                    var newSize = customRoundSize(chSize, minForLayer);
                    // only set when changed to avoid unnecessary writes
                    if (Math.abs(newSize - chSize) > 0.0001) {
                        ch.characterAttributes.size = newSize;
                    }
                } catch (e) { /* per-char safe fail */ }
            }
        }

        // C) snap strokes in this layer
        var paths = collectPathItems(layer);
        for (var p = 0; p < paths.length; p++) {
            try { paths[p].strokeWidth = snapStrokeWidth(paths[p].strokeWidth); } catch (e) {}
        }

        // D) delete any leftover empty textframes in this layer
        var tfsRem = collectTextFrames(layer);
        for (var r = tfsRem.length - 1; r >= 0; r--) {
            var tfr = tfsRem[r];
            if (!tfr) continue;
            try { if (isEmptyTextFrame(tfr)) tfr.remove(); } catch(e){}
        }

        // E) Move content to top and crop artboard bottom to fit content
        try {
            var artRect = rectObj(ab.artboardRect);
            var items = layer.pageItems;
            if (!items || items.length === 0) continue;

            var trueTop = -Infinity;
            var trueBottom = Infinity;
            var saw = false;
            for (var k = 0; k < items.length; k++) {
                try {
                    var vb = items[k].visibleBounds;
                    if (!vb || vb.length !== 4) continue;
                    saw = true;
                    if (vb[1] > trueTop) trueTop = vb[1];
                    if (vb[3] < trueBottom) trueBottom = vb[3];
                } catch (e) {}
            }
            if (!saw || !isFinite(trueTop) || !isFinite(trueBottom)) continue;

            var dy = artRect.top - trueTop;
            for (var m = 0; m < items.length; m++) { try { items[m].translate(0, dy); } catch(e){} }

            var newTop = trueTop + dy;
            var newBottom = trueBottom + dy;
            var newHeight = Math.abs(newTop - newBottom);
            if (!isFinite(newHeight) || newHeight <= 0) continue;

            var newBottomCoord = artRect.top - newHeight;
            var newRect = [artRect.left, artRect.top, artRect.right, newBottomCoord];
            try { ab.artboardRect = newRect; } catch (e) {
                // fallback set by index
                try { var idx = doc.artboards.getIndex(ab); if (typeof idx === 'number') doc.artboards[idx].artboardRect = newRect; } catch (ee) {}
            }
        } catch (e) {}
    } // end artboard loop

    // Ensure Illustrator paints changes
    safe(function(){ app.redraw(); }); try { $.sleep(150); } catch(e) {}

    // ---------- 3) Remove truly empty top-level layers (recursively) ----------
    function isLayerCompletelyEmpty(layer) {
        try {
            if (layer.pageItems && layer.pageItems.length > 0) return false;
            if (!layer.layers || layer.layers.length === 0) return true;
            for (var i = 0; i < layer.layers.length; i++) {
                if (!isLayerCompletelyEmpty(layer.layers[i])) return false;
            }
            return true;
        } catch (e) { return false; }
    }

    var removedLayerNames = [];
    for (var li = doc.layers.length - 1; li >= 0; li--) {
        try {
            var L = doc.layers[li];
            if (!L || L.locked || !L.visible) continue;
            if (isLayerCompletelyEmpty(L)) {
                removedLayerNames.push(L.name);
                try { L.remove(); } catch (e) {}
            }
        } catch (e) {}
    }

    // Final redraw and brief pause
    safe(function(){ app.redraw(); }); try { $.sleep(150); } catch(e) {}

    // Final alert: success + removed layers summary
    var msg = "✅ AutoPerfect: Magic Fix Completed.";
    if (removedLayerNames.length) {
        msg += "\n\nRemoved empty layers (" + removedLayerNames.length + "):\n";
        for (var ri = 0; ri < removedLayerNames.length; ri++) msg += "• " + removedLayerNames[ri] + "\n";
    } else {
        msg += "\n\nNo empty layers found.";
    }
    alert(msg);

})();