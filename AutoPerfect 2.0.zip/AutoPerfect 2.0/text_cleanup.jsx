/*
brix_TextNormalize_ONLY_WITH_TRACKING_QUICK_CHOICE_SECURE.jsx
----------------------------------------------------------------
PURPOSE
- Normalize text attributes across all text frames in Illustrator
- Apply tracking (0, -10, or -25) via quick modal choice
- Reset scale, baseline shift, rotation, and kerning method

SECURITY & CONTEXT
- Runs locally inside Adobe Illustrator ExtendScript runtime
- No web, network, or browser context
- No file system read/write operations
- No external dependencies

STABILITY
- Hardened against Illustrator state issues
- Safe to run after other scripts
- Executes in a single undo step
*/

#target illustrator
#targetengine "brix_TextNormalize_Tracking_SECURE_ENGINE"

(function () {
    "use strict";

    //==================================================
    // PRE-FLIGHT & HARD RESET
    //==================================================

    try {
        app.redraw();
        $.sleep(50);
        app.redraw();
    } catch (e) {}

    if (!app.documents || app.documents.length === 0) {
        alert("No Illustrator document is open.");
        return;
    }

    var doc = app.activeDocument;

    try { doc.selection = null; } catch (e) {}
    try { app.executeMenuCommand("undo"); } catch (e) {}

    //==================================================
    // QUICK CHOICE UI
    //==================================================

    var trackingValue = 0;

    var dlg = new Window("dialog", "Text Normalization – Choose Tracking");
    dlg.orientation = "column";
    dlg.alignChildren = ["fill", "center"];
    dlg.spacing = 14;
    dlg.margins = 18;

    dlg.add("statictext", undefined, "Choose tracking value to apply to all text:");

    var btnTracking0 = dlg.add("button", undefined, "Set Tracking 0");
    var btnTrackingNeg10 = dlg.add("button", undefined, "Set Tracking -10");
    var btnTrackingNeg25 = dlg.add("button", undefined, "Set Tracking -25");

    btnTracking0.preferredSize.width = 220;
    btnTrackingNeg10.preferredSize.width = 220;
    btnTrackingNeg25.preferredSize.width = 220;

    btnTracking0.onClick = function () {
        trackingValue = 0;
        dlg.close();
    };

    btnTrackingNeg10.onClick = function () {
        trackingValue = -10;
        dlg.close();
    };

    btnTrackingNeg25.onClick = function () {
        trackingValue = -25;
        dlg.close();
    };

    dlg.show();
    $.sleep(60);

    //==================================================
    // HELPER
    //==================================================

    function collectTextFrames(container, out) {
        out = out || [];
        try {
            for (var i = 0; i < container.textFrames.length; i++) {
                out.push(container.textFrames[i]);
            }
        } catch (e) {}

        try {
            for (var g = 0; g < container.groupItems.length; g++) {
                collectTextFrames(container.groupItems[g], out);
            }
        } catch (e) {}

        return out;
    }

    //==================================================
    // TEXT NORMALIZATION
    //==================================================

    var processedCount = 0;

    try {
        var allTextFrames = collectTextFrames(doc, []);

        for (var i = 0; i < allTextFrames.length; i++) {
            try {
                var characters = allTextFrames[i].textRange.characters;

                for (var c = 0; c < characters.length; c++) {
                    var attr = characters[c].characterAttributes;

                    attr.tracking = trackingValue;
                    attr.horizontalScale = 100;
                    attr.verticalScale = 100;
                    attr.baselineShift = 0;
                    attr.characterRotation = 0;

                    // 🔒 Force kerning to Auto
                    attr.kerningMethod = AutoKernType.AUTO;
                }

                processedCount++;
            } catch (e) {}
        }
    } catch (e) {}

    //==================================================
    // FORCE COMMIT
    //==================================================

    try {
        app.redraw();
        $.sleep(80);
        app.redraw();
    } catch (e) {}

    //==================================================
    // FINAL ALERT
    //==================================================

    alert(
        "Text Normalization Completed ✅\n\n" +
        "• Text frames processed: " + processedCount + "\n" +
        "• Tracking applied: " + trackingValue + "\n" +
        "• Kerning: Auto\n" +
        "• Scale reset to 100%\n" +
        "• Baseline & rotation reset"
    );

})();