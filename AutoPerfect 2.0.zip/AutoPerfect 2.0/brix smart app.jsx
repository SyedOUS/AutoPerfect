// Magic Fix - Branding Update + Dark Grey Credits
// Version 2.8.2
#target illustrator
#targetengine "MagicFix_ButtonAbbrev_v252"

// --- START JSON POLYFILL ---
if (typeof JSON !== "object") { JSON = {}; }
(function () {
    "use strict";
    if (typeof JSON.stringify !== "function") {
        JSON.stringify = function (value) {
            var type = typeof value;
            if (type === "string") {
                return '"' + value.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r') + '"';
            }
            if (type === "number" || type === "boolean") { return String(value); }
            return "null";
        };
    }
})();
// --- END JSON POLYFILL ---

(function () {
    "use strict";

    /* =========================================================
       CONFIG
    ========================================================= */
    var CONFIG = {
        scriptsFolderPath: File($.fileName).parent.fsName + "/",
        
        panel: { title: " ", width: 560, height: 100 },
        logo: { width: 182, height: 55, file: "icons/brix_logo.png" },
        button: { size: { w: 48, h: 48 }, gapX: 22 },
        colors: {
            darkBg: [0.176, 0.122, 0.354, 1]
        }
    };

    var ITEMS = [
        { label: "Quick Renditions", file: "brixSmartRenditions.jsx", abbrev: "QR" },
        { label: "Magic Fix",        file: "MagicFix.jsx",            abbrev: "FIX" },
        { label: "QC Unlocked",      file: "brix QC Unlocked.jsx",    abbrev: "QC" },
        { label: "Text Cleanup",     file: "text_cleanup.jsx",       abbrev: "TXT" },
        { label: "Export PNGs",      file: "exportPng.jsx",          abbrev: "PNG's" }
    ];

    /* =========================================================
       SECURITY & VALIDATION
    ========================================================= */
    function validateConfiguration() {
        if (!ITEMS || ITEMS.length === 0) {
            alert("Critical Error: The scripts registry (ITEMS) is empty or missing.");
            return false;
        }
        for (var i = 0; i < ITEMS.length; i++) {
            var item = ITEMS[i];
            if (!item.file || typeof item.file !== "string") {
                alert("Configuration Error: Item #" + (i+1) + " is missing a valid 'file' property.");
                return false;
            }
            if (!item.abbrev || typeof item.abbrev !== "string") {
                alert("Configuration Error: Item #" + (i+1) + " is missing a valid 'abbrev' property.");
                return false;
            }
        }
        return true;
    }

    function isAllowedScript(requestedFile) {
        for (var i = 0; i < ITEMS.length; i++) {
            if (ITEMS[i].file === requestedFile) {
                return true;
            }
        }
        return false;
    }

    /* =========================================================
       EXECUTION LOGIC
    ========================================================= */
    function launchViaBT(fileObj) {
        try {
            var bt = new BridgeTalk();
            bt.target = "illustrator";
            var safePath = JSON.stringify(fileObj.fsName);
            bt.body = "try { $.evalFile(File(" + safePath + ")); } catch(e) { alert('Inner BT Error: ' + e); }";
            bt.send();
        } catch (e) { 
            alert("BridgeTalk Failed: " + e); 
        }
    }

    function safeRunScript(relPath) {
        if (!isAllowedScript(relPath)) {
            alert("Security Alert: Execution blocked.\nThe script '" + relPath + "' is not in the allow-list.");
            return;
        }

        var file = new File(CONFIG.scriptsFolderPath + relPath);
        
        if (!file.exists) { 
            alert("Script file missing:\n" + file.fsName); 
            return; 
        }
        
        try {
            $.evalFile(file);
        } catch (e) {
            launchViaBT(file);
        }
    }

    /* =========================================================
       UI CONSTRUCTION
    ========================================================= */
    function createWindow() {
        if (!validateConfiguration()) return;

        if ($.global.magicFixWin instanceof Window) {
            $.global.magicFixWin.close();
            $.global.magicFixWin = null;
        }

        var win = new Window("palette", CONFIG.panel.title, undefined, { closeButton: false });
        win.margins = [10,10,10,10];
        
        try { win.graphics.backgroundColor = win.graphics.newBrush(win.graphics.BrushType.SOLID_COLOR, CONFIG.colors.darkBg); } catch(e) {}

        var mainRow = win.add("group");
        mainRow.spacing = 18;

        // --- LEFT COLUMN: LOGO + CREDITS ---
        var logoGroup = mainRow.add("group");
        logoGroup.orientation = "column";
        logoGroup.alignChildren = "center";
        logoGroup.spacing = 0; // Removed extra spacing for tighter look

        var logoFile = File(CONFIG.scriptsFolderPath + CONFIG.logo.file);
        if (logoFile.exists) {
            var img = logoGroup.add("image", undefined, logoFile);
            img.size = [CONFIG.logo.width, CONFIG.logo.height];
        } else {
            var t = logoGroup.add("statictext", undefined, "BRIX");
            t.graphics.foregroundColor = win.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [1,1,1,1], 1);
        }

        // UI CHANGE: Updated Text, Size, and Color
        var credit = logoGroup.add("statictext", undefined, "Developed for Brix");
        try {
            // Dark Grey Color [R, G, B, Alpha]
            credit.graphics.foregroundColor = win.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.3, 0.3, 0.3, 1], 1);
            // Smaller Font (Size 9)
            credit.graphics.font = ScriptUI.newFont("Helvetica", "Regular", 9);
        } catch(e) {}
        // -----------------------------------

        var btnPanel = mainRow.add("group");
        btnPanel.spacing = CONFIG.button.gapX;

        for (var i = 0; i < ITEMS.length; i++) {
            var item = ITEMS[i];
            
            var col = btnPanel.add("group");
            col.orientation = "column";
            col.spacing = 4;

            var btn = col.add("button", undefined, item.abbrev);
            btn.size = [CONFIG.button.size.w, CONFIG.button.size.h];
            btn.helpTip = "Run " + item.label;

            btn.onClick = (function (path) {
                return function () {
                    safeRunScript(path);
                };
            })(item.file);

            var lbl = col.add("statictext", undefined, item.label);
            try { lbl.graphics.foregroundColor = win.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [1,1,1,1], 1); } catch(e) {}
            lbl.graphics.font = ScriptUI.newFont("Helvetica", "Regular", 9);
        }

        win.center();
        win.show();
        
        $.global.magicFixWin = win;
    }

    createWindow();
})();