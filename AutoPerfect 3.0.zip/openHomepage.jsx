/*
openHomepage.jsx
-------------------------------------------------------
Opens the AutoPerfect homepage in the default browser.

METHOD: .webloc file + File.execute()
  A .webloc is a native macOS web location file (plist XML).
  macOS always opens .webloc files in the default browser.
  File.execute() calls macOS's open command on the file —
  no shell access needed, no app.openURL, no app.doScript.
*/

#target illustrator
#targetengine "OpenHomepage_v1"

(function () {

    var url = "https://syedous.github.io/AutoPerfect/";

    // Fix 4: Validate URL starts with https:// before writing to disk
    if (url.indexOf("https://") !== 0) {
        alert("Invalid URL — must start with https://");
        return;
    }

    // Fix 1: XML-escape the URL before embedding in plist
    // Prevents malformed XML if url ever contains & < > " '
    function xmlEscape(str) {
        return str
            .replace(/&/g,  "&amp;")
            .replace(/</g,  "&lt;")
            .replace(/>/g,  "&gt;")
            .replace(/"/g,  "&quot;")
            .replace(/'/g,  "&apos;");
    }
    var safeUrl = xmlEscape(url);

    // Fix 3: Unique timestamped filename — safe for concurrent runs
    var tmpName = "autoperfect_" + (new Date().getTime()) + ".webloc";
    var weblocFile = new File(Folder.temp.fsName + "/" + tmpName);

    try {
        weblocFile.open("w");
        weblocFile.writeln('<?xml version="1.0" encoding="UTF-8"?>');
        weblocFile.writeln('<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">');
        weblocFile.writeln('<plist version="1.0">');
        weblocFile.writeln('<dict>');
        weblocFile.writeln('    <key>URL</key>');
        weblocFile.writeln('    <string>' + safeUrl + '</string>');
        weblocFile.writeln('</dict>');
        weblocFile.writeln('</plist>');
        weblocFile.close();

        // Execute — macOS routes .webloc to the default browser
        weblocFile.execute();

        // Fix 2: Delete temp file after execute()
        // Small sleep to allow macOS to read the file before removal
        $.sleep(1000);
        try { weblocFile.remove(); } catch(re) {}

    } catch (e) {
        try { weblocFile.close(); } catch(e2) {}
        try { weblocFile.remove(); } catch(e3) {}
        alert("Could not open browser automatically.\nPlease visit:\n\n" + url);
    }

})();
