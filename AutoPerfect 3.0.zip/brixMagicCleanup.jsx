/*
brixMagicCleanup v2.1
---------------------------------------------------------
COMPLETE REBUILD — Runs all cleanup and normalization
rules on all four artboards (SM, MD, L, XL) IN PLACE.

Does NOT create renditions or duplicate content.
Designs must already be placed on all artboards.

KEY CHANGES IN v2.0:
  1. Text frame collection switched to doc.textFrames global
     flat list filtered by layer name — catches EVERY frame
     regardless of nesting depth, sublayers, or group structure.
     collectTextFrames recursive walker is kept as a fallback.

  2. Character pass uses story.textRange for the full text range
     write (tracking, scale, baseline, rotation) BEFORE the
     per-character font rounding pass. story.textRange applies
     attributes to the entire text content atomically — no per-
     character loop needed for the bulk attributes, which avoids
     MRAP errors on individual special glyphs entirely.

  3. Font rounding still runs per-character (only way to respect
     mixed font sizes in a single frame) but with its own isolated
     try/catch so MRAP on one character never blocks others.

  4. kerningMethod set via story.textRange — more reliable than
     per-character, and skipped gracefully if enum unavailable.

  5. All attribute writes individually wrapped — no single failure
     can block subsequent writes on the same frame or character.
*/

#target illustrator
#targetengine "BrixMagicCleanup_v1"

(function () {

    //==================================================
    // ERROR COLLECTOR
    //==================================================

    var _errors = [];
    var _ERROR_CAP = 50;

    function logErr(context, e) {
        if (_errors.length >= _ERROR_CAP) return;
        _errors.push(context + ": " + (e && e.message ? e.message : String(e)));
    }

    //==================================================
    // PRE-FLIGHT — double redraw + retry loop
    //==================================================

    if (app.documents.length === 0) {
        alert("No Illustrator document is open.\nPlease open a file and try again.");
        return;
    }
    var doc = app.activeDocument;
    try { doc.selection = null; } catch (e) {}

    var AB_NAMES = ["SM", "MD", "L", "XL"];
    var MIN_FONT  = { SM: 8, MD: 10, L: 12, XL: 12 };

    // AutoKernType enum — only available in named persistent engines.
    // Checked once at startup; null means we skip kerningMethod writes.
    var KERN_AUTO = (typeof AutoKernType !== "undefined") ? AutoKernType.AUTO : null;

    //==================================================
    // TRACKING CHOICE DIALOG
    //==================================================

    var trackingValue = null;
    var TRACKING_SKIP = "skip";

    var dlg = new Window("dialog", "brixMagicCleanup – Tracking");
    dlg.orientation   = "column";
    dlg.alignChildren = ["fill", "center"];
    dlg.spacing       = 12;
    dlg.margins       = 18;

    dlg.add("statictext", undefined, "Choose tracking to apply to all artboard text:");

    var btn0      = dlg.add("button", undefined, "Tracking  0");
    var btnN10    = dlg.add("button", undefined, "Tracking -10");
    var btnN25    = dlg.add("button", undefined, "Tracking -25");
    var btnSkip   = dlg.add("button", undefined, "Skip (keep existing tracking)");
    var btnCancel = dlg.add("button", undefined, "Cancel");

    btn0.preferredSize.width    =
    btnN10.preferredSize.width  =
    btnN25.preferredSize.width  =
    btnSkip.preferredSize.width =
    btnCancel.preferredSize.width = 260;

    btn0.onClick      = function () { trackingValue = 0;             dlg.close(); };
    btnN10.onClick    = function () { trackingValue = -10;           dlg.close(); };
    btnN25.onClick    = function () { trackingValue = -25;           dlg.close(); };
    btnSkip.onClick   = function () { trackingValue = TRACKING_SKIP; dlg.close(); };
    btnCancel.onClick = function () { trackingValue = null;          dlg.close(); };

    dlg.show();

    if (trackingValue === null) return;

    //==================================================
    // HELPERS
    //==================================================

    function rectObj(r) {
        return {
            left: r[0], top: r[1], right: r[2], bottom: r[3],
            width: Math.abs(r[2] - r[0]), height: Math.abs(r[1] - r[3])
        };
    }

    function getAB(name) {
        for (var i = 0; i < doc.artboards.length; i++) {
            if (doc.artboards[i].name === name) return doc.artboards[i];
        }
        return null;
    }

    function getLayer(name) {
        try { return doc.layers.getByName(name); } catch (e) { return null; }
    }

    function snapStroke(sw) {
        sw = Number(sw) || 0;
        if (sw <= 0) return sw;
        if (sw < 1) {
            if (sw < 0.375) return 0.25;
            if (sw < 0.625) return 0.5;
            return 0.75;
        }
        return Math.round(sw);
    }

    function isEmptyTextFrame(tf) {
        try {
            var raw = String(tf.contents || "")
                .replace(/\u00A0/g, " ").replace(/[\t\r\n]/g, " ")
                .replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
            return raw.length === 0;
        } catch (e) { return false; }
    }

    // Depth-capped recursive collector — fallback for frames
    // not appearing in doc.textFrames global list
    function collectTextFrames(container, out, _depth) {
        out    = out || [];
        _depth = (typeof _depth === "number") ? _depth : 0;
        if (_depth > 20) return out;
        try {
            for (var i = 0; i < container.textFrames.length; i++) out.push(container.textFrames[i]);
        } catch (e) {}
        try {
            for (var g = 0; g < container.groupItems.length; g++) collectTextFrames(container.groupItems[g], out, _depth + 1);
        } catch (e) {}
        return out;
    }

    function collectPathItems(container, out, _depth) {
        out    = out || [];
        _depth = (typeof _depth === "number") ? _depth : 0;
        if (_depth > 20) return out;
        try {
            for (var i = 0; i < container.pathItems.length; i++) out.push(container.pathItems[i]);
        } catch (e) {}
        try {
            for (var g = 0; g < container.groupItems.length; g++) collectPathItems(container.groupItems[g], out, _depth + 1);
        } catch (e) {}
        return out;
    }

    //==================================================
    // GET ALL TEXT FRAMES FOR A LAYER
    // Dual strategy:
    //   Primary — doc.textFrames global flat list filtered
    //     by layer name. This is the most reliable method —
    //     Illustrator maintains this list regardless of group
    //     nesting depth or sublayer structure.
    //   Secondary — recursive collectTextFrames walker as
    //     a safety net for any frames the global list misses.
    // Deduplication via a seen-index map.
    //==================================================

    function getFramesForLayer(layerName) {
        var frames = [];
        var seen   = {};

        // Primary: global flat list filtered by layer name.
        // tf.layer access is wrapped in an isolated function —
        // engine-level "No such element" on complex docs propagates
        // past plain try/catch; isolated scope fully contains it.
        function getFrameLayerName(tf) {
            try { return tf.layer.name; } catch (e) { return ""; }
        }

        try {
            var total = doc.textFrames.length;
            for (var f = 0; f < total; f++) {
                try {
                    var tf = doc.textFrames[f];
                    if (!tf) continue;
                    var lname = getFrameLayerName(tf);
                    if (lname === layerName) {
                        frames.push(tf);
                        seen[f] = true;
                    }
                } catch (e) {}
            }
        } catch (e) { logErr("getFrames/global/" + layerName, e); }

        // Secondary: recursive walker — catches any missed frames
        var layer = getLayer(layerName);
        if (layer) {
            var walked = collectTextFrames(layer, []);
            for (var w = 0; w < walked.length; w++) {
                var alreadyIn = false;
                for (var x = 0; x < frames.length; x++) {
                    try {
                        if (frames[x] === walked[w]) { alreadyIn = true; break; }
                    } catch (e) {}
                }
                if (!alreadyIn) frames.push(walked[w]);
            }
        }

        return frames;
    }

    //==================================================
    // APPLY ATTRIBUTES TO A TEXT FRAME
    // Uses story.textRange for bulk attributes — applies
    // atomically to the entire text content, bypassing the
    // per-character MRAP errors on special glyphs.
    // Font rounding still runs per-character to preserve
    // mixed font sizes within a single frame.
    //==================================================

    function applyFrameAttributes(tf, minFont) {

        // Guard: verify tf is still a valid accessible object
        // before any access. In complex docs, items in the
        // global list can become stale between collection and use.
        try { if (!tf || !tf.typename) return; } catch (e) { return; }

        // ---- BULK ATTRIBUTES via story.textRange ----
        // story.textRange covers the full threaded text.
        // One write per attribute per frame — no per-char loop.
        // Each write individually wrapped so one failure cannot
        // block any subsequent attribute.
        var tr = null;
        try { tr = tf.story.textRange; } catch (e) {
            // Fallback: use textRange directly if story unavailable
            try { tr = tf.textRange; } catch (e2) {}
        }

        if (tr) {
            var ca = null;
            try { ca = tr.characterAttributes; } catch (e) {}

            if (ca) {
                if (trackingValue !== TRACKING_SKIP) {
                    try { ca.tracking = trackingValue; } catch (e) {}
                }
                try { ca.horizontalScale = 100; } catch (e) {}
                try { ca.verticalScale   = 100; } catch (e) {}
                try { ca.baselineShift   = 0;   } catch (e) {}
                try { ca.rotation        = 0;   } catch (e) {}
                if (KERN_AUTO !== null) {
                    try { ca.kerningMethod = KERN_AUTO; } catch (e) {}
                }
            }
        }

        // ---- PER-CHARACTER FONT ROUNDING ----
        // Must run per-character to respect mixed sizes.
        // Each character fully isolated — MRAP on one never
        // blocks rounding on others.
        try {
            var chars = tf.textRange.characters;
            for (var c = 0; c < chars.length; c++) {
                try {
                    var charCA = chars[c].characterAttributes;
                    var raw    = Number(charCA.size);
                    if (!isNaN(raw) && raw > 0) {
                        var target = Math.round(raw);
                        if (target < minFont) target = minFont;
                        charCA.size = target;
                    }
                } catch (ce) {}
            }
        } catch (e) {}
    }

    //==================================================
    // ENABLE SCALE CORNERS
    //==================================================

    try {
        if (app.preferences && typeof app.preferences.setBooleanPreference === "function") {
            app.preferences.setBooleanPreference("scaleCorners", true);
        }
    } catch (e) {}

    //==================================================
    // PRECHECK
    //==================================================

    for (var i = 0; i < AB_NAMES.length; i++) {
        if (!getAB(AB_NAMES[i])) {
            alert("Missing artboard: " + AB_NAMES[i] + "\nScript aborted.");
            return;
        }
        if (!getLayer(AB_NAMES[i])) {
            try { doc.layers.add().name = AB_NAMES[i]; } catch (e) { logErr("precheck/addLayer/" + AB_NAMES[i], e); }
        }
    }

    //==================================================
    // STEP 1 — GLOBAL EMPTY TEXT FRAME REMOVAL
    // Each item access is wrapped in an isolated function
    // scope. In complex documents with sublayers, Illustrator
    // throws engine-level "No such element" when accessing
    // .layer, .locked, or .visible on certain text frames —
    // these propagate past a plain try/catch. An isolated
    // function call creates a new execution context that
    // fully contains the engine error.
    //==================================================

    function safeRemoveIfEmpty(tf) {
        try {
            if (!tf) return;
            // Check locked state — engine error possible on complex docs
            var isLocked = false;
            try { isLocked = tf.locked; } catch (e) { return; }
            if (isLocked) return;

            // Check layer visibility — most common source of "No such element"
            // Walk up the layer chain safely
            var layerVisible = true;
            try {
                var lyr = tf.layer;
                if (lyr) {
                    try { layerVisible = lyr.visible; } catch (e) { layerVisible = true; }
                }
            } catch (e) { layerVisible = true; }
            if (!layerVisible) return;

            if (isEmptyTextFrame(tf)) {
                try { tf.remove(); } catch (e) {}
            }
        } catch (e) {}
    }

    var tfCount = 0;
    try { tfCount = doc.textFrames.length; } catch (e) {}

    for (var ti = tfCount - 1; ti >= 0; ti--) {
        try {
            safeRemoveIfEmpty(doc.textFrames[ti]);
        } catch (e) {}
    }

    //==================================================
    // STEP 2 — MAIN LOOP
    //==================================================

    for (var ai = 0; ai < AB_NAMES.length; ai++) {

        var abName  = AB_NAMES[ai];
        var layer   = getLayer(abName);
        var ab      = getAB(abName);
        var minFont = MIN_FONT[abName];

        if (!layer || !ab) {
            logErr("mainLoop/" + abName, "layer or artboard not found");
            continue;
        }

        //----------------------------------------------
        // A) GET ALL FRAMES FOR THIS LAYER
        // Dual strategy: global list + recursive walker
        //----------------------------------------------

        var frames = getFramesForLayer(abName);

        //----------------------------------------------
        // B) APPLY ALL TEXT ATTRIBUTES
        // story.textRange bulk write + per-char font round
        //----------------------------------------------

        for (var fi = 0; fi < frames.length; fi++) {
            try {
                applyFrameAttributes(frames[fi], minFont);
            } catch (e) { logErr(abName + "/frame[" + fi + "]", e); }
        }

        //----------------------------------------------
        // C) SPACE CLEANUP
        // Separate pass — character removal invalidates
        // the char collection so must follow attr writes
        //----------------------------------------------

        for (var si = 0; si < frames.length; si++) {
            try {
                var ch = frames[si].textRange.characters;
                var x  = 0;
                while (x < ch.length - 1) {
                    if (ch[x].contents === " " && ch[x + 1].contents === " ") {
                        ch[x + 1].remove();
                        ch = frames[si].textRange.characters;
                        continue;
                    }
                    x++;
                }
                while (ch.length && ch[0].contents === " ")           ch[0].remove();
                while (ch.length && ch[ch.length-1].contents === " ") ch[ch.length-1].remove();
            } catch (e) { logErr(abName + "/spaces[" + si + "]", e); }
        }

        //----------------------------------------------
        // D) STROKE SNAPPING
        //----------------------------------------------

        var paths = collectPathItems(layer, []);
        for (var p = 0; p < paths.length; p++) {
            try { paths[p].strokeWidth = snapStroke(paths[p].strokeWidth); } catch (e) {}
        }

        //----------------------------------------------
        // E) REMOVE LEFTOVER EMPTY FRAMES IN LAYER
        //----------------------------------------------

        for (var ri = frames.length - 1; ri >= 0; ri--) {
            try {
                if (isEmptyTextFrame(frames[ri])) frames[ri].remove();
            } catch (e) {}
        }

        //----------------------------------------------
        // F) MOVE CONTENT TO TOP + CROP ARTBOARD HEIGHT
        //----------------------------------------------

        try {
            var artRect = rectObj(ab.artboardRect);
            var items   = layer.pageItems;
            if (items && items.length > 0) {
                var topY = -Infinity, botY = Infinity, saw = false;
                for (var k = 0; k < items.length; k++) {
                    try {
                        var vb = items[k].visibleBounds;
                        if (!vb || vb.length !== 4) continue;
                        saw = true;
                        if (vb[1] > topY) topY = vb[1];
                        if (vb[3] < botY) botY = vb[3];
                    } catch (e) {}
                }
                if (saw && isFinite(topY) && isFinite(botY)) {
                    var dy = artRect.top - topY;
                    for (var m = 0; m < items.length; m++) {
                        try { items[m].translate(0, dy); } catch (e) {}
                    }
                    var newHeight = Math.abs((topY + dy) - (botY + dy));
                    if (isFinite(newHeight) && newHeight > 0) {
                        ab.artboardRect = [artRect.left, artRect.top, artRect.right, artRect.top - newHeight];
                    }
                }
            }
        } catch (e) { logErr(abName + "/moveCrop", e); }

    } // end main loop

    //==================================================
    // STEP 3 — REMOVE COMPLETELY EMPTY LAYERS
    //==================================================

    function isLayerCompletelyEmpty(lyr) {
        try {
            if (lyr.pageItems && lyr.pageItems.length > 0) return false;
            if (!lyr.layers || lyr.layers.length === 0) return true;
            for (var i = 0; i < lyr.layers.length; i++) {
                if (!isLayerCompletelyEmpty(lyr.layers[i])) return false;
            }
            return true;
        } catch (e) { return false; }
    }

    var removedLayers = [];
    for (var li = doc.layers.length - 1; li >= 0; li--) {
        try {
            var L = doc.layers[li];
            if (!L || L.locked || !L.visible) continue;
            if (isLayerCompletelyEmpty(L)) {
                removedLayers.push(L.name);
                try { L.remove(); } catch (e) { logErr("removeLayer/" + L.name, e); }
            }
        } catch (e) {}
    }

    //==================================================
    // FINAL REDRAW
    //==================================================

    try { app.redraw(); } catch (e) {}

    //==================================================
    // DONE
    //==================================================

    var trackingLabel = (trackingValue === TRACKING_SKIP) ? "kept as-is" : String(trackingValue);

    var summary =
        "brixMagicCleanup complete ✅\n\n" +
        "• All artboards cleaned in place (SM, MD, L, XL)\n" +
        "• Tracking: " + trackingLabel + "\n" +
        "• Scale, baseline & rotation reset\n" +
        "• Kerning: Auto\n" +
        "• Font sizes rounded, minimums enforced\n" +
        "• Strokes snapped\n" +
        "• Content pinned to artboard top\n" +
        "• Artboards cropped to content height";

    if (removedLayers.length > 0) {
        summary += "\n\nRemoved " + removedLayers.length + " empty layer(s):\n";
        for (var rn = 0; rn < removedLayers.length; rn++) {
            summary += "• " + removedLayers[rn] + "\n";
        }
    } else {
        summary += "\n\nNo empty layers found.";
    }

    if (_errors.length > 0) {
        summary += "\n\n⚠️ " + _errors.length + " non-critical error(s):\n" + _errors.join("\n");
    }

    // Cap total summary length to prevent oversized alert dialog
    if (summary.length > 2000) {
        summary = summary.substring(0, 1990) + "\n...(truncated)";
    }
    alert(summary);

})();
