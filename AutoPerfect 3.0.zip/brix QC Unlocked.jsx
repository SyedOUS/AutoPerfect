// =============================================================
//  Brix QC Script — Illustrator Brand Compliance Checker
//  v3.0 · Lilly + Product Brands · Dynamic HTML Report
//  Checks: decimal fonts · double spaces · stroke widths
//          outside artboard · swatch naming · off-brand colors
//          unapproved fonts
// =============================================================

// ---------- entry point ----------
function main() {
    if (app.documents.length === 0) { alert("No document open."); return; }

    var doc      = app.activeDocument;
    var docName  = doc.name.replace(/\.ai$/i, "");

    // ── FILENAME SYMBOL CHECK ──
    var BAD_CHARS = ['_','-','!','@','#','$','%','^','&','*','(',')','{','}','"',':','>','<','?','.','|','\\','=','+','₹','~'];
    var foundBadChars = [];
    for (var fc=0; fc<BAD_CHARS.length; fc++) {
        if (docName.indexOf(BAD_CHARS[fc]) !== -1) foundBadChars.push(BAD_CHARS[fc]);
    }
    var fileNameHasIssue = (foundBadChars.length > 0);

    // =========================================================
    //  BRAND PROFILES
    // =========================================================
    var PROFILES = {

        "Lilly Core": {
            fonts: ["ringside","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","itc garamond narrow","garamond","itcgaramond"],
            palette: [
                [251,207,200],[33,33,33],[15,58,133],[20,75,45],[138,150,158],[254,240,216],
                [253,232,229],[198,220,216],[228,235,241],[153,191,229],[245,142,125],[253,209,176],
                [255,255,255],[0,175,63],[225,37,27],[82,18,7],[255,199,9],[0,0,0]
            ]
        },
        "Mounjaro": {
            fonts: ["mark pro","markpro","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                [62,115,185],[88,89,91],[199,38,5],[198,0,126],[63,42,90],[236,234,238],
                [226,223,230],[159,148,172],[112,115,114],[219,220,220],[55,125,111],[250,66,66],
                [254,236,236],[254,217,217],[252,142,142],[93,0,150],[242,235,247],[239,229,244],
                [223,204,234],[133,64,176],[211,183,224],[168,0,107],[255,255,255],[0,0,0]
            ]
        },
        "Zepbound": {
            fonts: ["tt commons pro","ttcommonspro","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                [5,147,240],[0,122,205],[0,138,38],[112,115,114],[223,52,24],[64,169,41],
                [205,233,252],[228,248,204],[230,230,230],[121,222,0],[250,66,66],[37,64,89],
                [255,255,255],[0,0,0]
            ]
        },
        "Jaypirca": {
            fonts: ["slate pro","slatepro","slate pro family","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                // Original Jaypirca colors
                [91,128,59],[184,0,78],[182,226,0],[217,217,217],[111,116,128],
                [238,0,109],[55,62,79],[255,255,255],[0,0,0],
                // Pirto brand colors
                [55,62,79],    // Pirto Dark Slate   #373e4f
                [182,226,0],   // Pirto Green        #b6e200
                [233,233,233], // Pirto Light Gray   #e9e9e9
                [91,128,59],   // Pirto Dark Green   #5b803b
                [173,191,157], // Pirto Dark Green 2 #adbf9d
                [227,245,158], // Pirto Light Green  #e3f59e
                [111,116,128]  // Pirto Light Slate  #6f7480
            ]
        },
        "Kisunla": {
            fonts: ["din pro","dinpro","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                [91,103,112],[236,237,235],[173,179,184],[255,133,0],[80,35,97],
                [194,84,0],[255,192,0],[255,255,255],[0,0,0]
            ]
        },
        "Verzinio": {
            fonts: ["avenir next","avenirnext","avenir","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                [0,171,199],[99,102,106],[48,25,70],[0,0,110],[0,105,143],
                [239,240,240],[218,120,192],[144,99,173],[255,255,255],[0,0,0]
            ]
        },
        "Ebglyss": {
            fonts: ["goldplay","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                [142,97,195],[102,102,102],[34,52,106],[180,125,216],[105,160,110],
                [67,83,128],[235,235,235],[202,245,168],[179,179,179],[122,69,184],
                [255,255,255],[0,0,0]
            ]
        },
        "Orforglipron": {
            fonts: ["ringside","ring side","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","garamond"],
            palette: [
                [73,113,208],[0,131,138],[233,233,233],[0,165,173],[32,55,105],[141,231,220],
                [126,157,47],[238,111,51],[132,70,173],[88,89,91],[154,49,118],[82,126,251],
                [255,255,255],[0,0,0]
            ]
        },
        "Emgality": {
            fonts: ["arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                [99,102,106],[238,83,64],[240,179,35],[169,194,63],[0,140,149],
                [255,255,255],[0,0,0]
            ]
        },
        "Onswik": {
            fonts: ["arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                [255,45,105],[28,16,248],[240,110,22],[137,60,189],[91,103,112],
                [0,150,140],[254,245,0],[255,255,255],[0,0,0]
            ]
        },
        "Omvoh": {
            fonts: ["mont","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                [0,51,160],[151,216,1],[255,255,255],[32,38,33],[243,209,72],
                [237,140,0],[115,118,130],[241,241,242],[115,101,136],[0,0,0]
            ]
        },
        "Inluriyo": {
            fonts: ["isidora","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                [191,235,219],[171,187,251],[69,71,102],[238,239,241],[218,120,192],
                [144,99,173],[115,117,140],[221,228,253],[223,245,237],[162,163,178],
                [89,94,182],[255,255,255],[0,0,0]
            ]
        },
        "Amyvid": {
            fonts: ["arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","ringside","garamond"],
            palette: [
                [230,242,247],[204,229,239],[153,204,222],[237,237,238],[186,93,0],
                [227,190,153],[241,223,204],[99,102,106],[255,255,255],[0,0,0]
            ]
        },
        "All Lilly Brands": {
            fonts: ["ringside","arial","times new roman","timesnewroman","ibm plex sans","ibmplexsans","garamond","itcgaramond",
                    "mark pro","markpro","tt commons pro","ttcommonspro","slate pro","slatepro",
                    "din pro","dinpro","avenir next","avenirnext","avenir","goldplay","isidora","mont"],
            palette: [
                [251,207,200],[33,33,33],[15,58,133],[20,75,45],[138,150,158],[254,240,216],
                [253,232,229],[198,220,216],[228,235,241],[153,191,229],[245,142,125],[253,209,176],
                [0,175,63],[225,37,27],[82,18,7],[255,199,9],
                [62,115,185],[88,89,91],[199,38,5],[198,0,126],[63,42,90],[236,234,238],
                [226,223,230],[159,148,172],[112,115,114],[219,220,220],[55,125,111],[250,66,66],
                [254,236,236],[254,217,217],[252,142,142],[93,0,150],[242,235,247],[239,229,244],
                [223,204,234],[133,64,176],[211,183,224],[168,0,107],
                [5,147,240],[0,122,205],[0,138,38],[223,52,24],[228,248,204],[205,233,252],
                [121,222,0],[37,64,89],[64,169,41],[230,230,230],
                [91,128,59],[184,0,78],[182,226,0],[217,217,217],[111,116,128],[238,0,109],[55,62,79],
                [173,191,157],[227,245,158],[233,233,233],
                [91,103,112],[236,237,235],[173,179,184],[255,133,0],[80,35,97],[194,84,0],[255,192,0],
                [0,171,199],[99,102,106],[48,25,70],[0,0,110],[0,105,143],[239,240,240],[218,120,192],[144,99,173],
                [142,97,195],[102,102,102],[34,52,106],[180,125,216],[105,160,110],[67,83,128],
                [235,235,235],[202,245,168],[179,179,179],[122,69,184],
                [73,113,208],[0,131,138],[233,233,233],[0,165,173],[32,55,105],[141,231,220],
                [126,157,47],[238,111,51],[132,70,173],[154,49,118],[82,126,251],
                [238,83,64],[240,179,35],[169,194,63],[0,140,149],
                [255,45,105],[28,16,248],[240,110,22],[137,60,189],[0,150,140],[254,245,0],
                [0,51,160],[151,216,1],[32,38,33],[243,209,72],[237,140,0],[115,118,130],[241,241,242],[115,101,136],
                [191,235,219],[171,187,251],[69,71,102],[238,239,241],[221,228,253],[89,94,182],
                [162,163,178],[115,117,140],[223,245,237],
                [230,242,247],[204,229,239],[153,204,222],[237,237,238],[186,93,0],
                [227,190,153],[241,223,204],
                [255,255,255],[0,0,0]
            ]
        }
    };


    // =========================================================
    //  STEP 1 — BRAND SELECTOR
    // =========================================================
    var brandKeys = [];
    for (var bk in PROFILES) brandKeys.push(bk);

    var menu = "Select brand — enter number:\n\n";
    for (var bi = 0; bi < brandKeys.length; bi++) menu += (bi + 1) + ".  " + brandKeys[bi] + "\n";

    var dlg = prompt(menu, "1");
    if (dlg === null || String(dlg).replace(/\s/g, "") === "") return;

    var brandName = "";
    var dlgN = parseInt(dlg, 10);
    if (!isNaN(dlgN) && dlgN >= 1 && dlgN <= brandKeys.length) {
        brandName = brandKeys[dlgN - 1];
    } else {
        var dlgL = String(dlg).toLowerCase().replace(/\s/g, "");
        for (var bi2 = 0; bi2 < brandKeys.length; bi2++) {
            if (brandKeys[bi2].toLowerCase().replace(/\s/g, "").indexOf(dlgL) !== -1) {
                brandName = brandKeys[bi2]; break;
            }
        }
        if (!brandName) { alert("Not recognised — using 'All Lilly Brands'."); brandName = "All Lilly Brands"; }
    }

    var BRAND    = PROFILES[brandName];
    var PALETTE  = BRAND.palette;
    var FONTS    = BRAND.fonts;
    var TOLERANCE = 0; // exact match — zero tolerance

    // =========================================================
    //  TYPOGRAPHY RULES — per brand
    //  tracking: required tracking value (null = must be 0)
    //  Foundayo is not in the brand list but handled as a special case
    // =========================================================
    var TRACKING_RULES = {
        "Mounjaro":        -10,
        "Omvoh":           -10,
        "Foundayo":        -25,
        "Lilly Core":        0,
        "Zepbound":          0,
        "Jaypirca":          0,
        "Kisunla":           0,
        "Verzinio":          0,
        "Ebglyss":           0,
        "Orforglipron":      0,
        "Emgality":          0,
        "Onswik":            0,
        "Inluriyo":          0,
        "Amyvid":            0,
        "All Lilly Brands":  0
    };
    var REQUIRED_TRACKING = (TRACKING_RULES[brandName] !== undefined)
                            ? TRACKING_RULES[brandName] : 0;

    // =========================================================
    //  STEP 2 — QC USER NAME (cached)
    // =========================================================
    var qcUser = "";
    try {
        var cf = new File(Folder.userData + "/Brix_QC_User.txt");
        if (cf.exists) { try { cf.open("r"); qcUser = cf.read(); cf.close(); } catch(e){} }
        if (!qcUser || qcUser.replace(/\s/g,"") === "") {
            qcUser = prompt("Your name (saved to this machine):", "");
            if (!qcUser || qcUser.replace(/\s/g,"") === "") qcUser = "Unknown";
            try { cf.open("w"); cf.encoding = "UTF-8"; cf.write(qcUser); cf.close(); } catch(e){}
        }
    } catch(e) { qcUser = "Unknown"; }
    qcUser = String(qcUser);

    // =========================================================
    //  SAVE FOLDER — RQR folder next to the source .ai file
    //  Source is expected under a "WORKFRONT UPLOADS" folder.
    //  We walk up to find the parent and create/use RQR there.
    //  If the doc is unsaved, fall back to Desktop/RQR.
    // =========================================================
    var saveFolder;
    try {
        var docPath = doc.path; // Folder object of the .ai file
        // Try to find or create RQR sibling folder
        var rqrFolder = new Folder(docPath.parent + "/RQR");
        if (!rqrFolder.exists) {
            rqrFolder.create();
        }
        saveFolder = rqrFolder;
    } catch(e) {
        // Doc not saved — use Desktop/RQR
        var desktopRQR = new Folder(Folder.desktop + "/RQR");
        if (!desktopRQR.exists) desktopRQR.create();
        saveFolder = desktopRQR;
    }

    // =========================================================
    //  HELPERS — COLOR
    // =========================================================
    function colorToRGB(c) {
        try {
            if (c.typename === "RGBColor")  return [Math.round(c.red), Math.round(c.green), Math.round(c.blue)];
            if (c.typename === "CMYKColor") {
                var K=c.black/100, C=c.cyan/100, M=c.magenta/100, Y=c.yellow/100;
                return [Math.round(255*(1-C)*(1-K)), Math.round(255*(1-M)*(1-K)), Math.round(255*(1-Y)*(1-K))];
            }
            if (c.typename === "GrayColor") { var v=Math.round(255*(1-c.gray/100)); return [v,v,v]; }
            if (c.typename === "SpotColor") return colorToRGB(c.spot.color);
        } catch(e) {}
        return null;
    }

    function distSq(r1,g1,b1,r2,g2,b2) { return (r1-r2)*(r1-r2)+(g1-g2)*(g1-g2)+(b1-b2)*(b1-b2); }

    function approvedColor(r,g,b) {
        // Each channel must be within TOLERANCE — catches intentional changes
        // while still allowing minor CMYK->RGB rounding differences (1-2 units)
        for (var p=0; p<PALETTE.length; p++) {
            var pr=PALETTE[p][0], pg=PALETTE[p][1], pb=PALETTE[p][2];
            if (Math.abs(r-pr)<=TOLERANCE && Math.abs(g-pg)<=TOLERANCE && Math.abs(b-pb)<=TOLERANCE)
                return true;
        }
        return false;
    }

    function toHex(r,g,b) {
        return "#"+("0"+r.toString(16)).slice(-2)+("0"+g.toString(16)).slice(-2)+("0"+b.toString(16)).slice(-2);
    }

    // =========================================================
    //  HELPERS — FONT
    // =========================================================
    function approvedFont(name) {
        if (!name) return true;
        var n = name.toLowerCase().replace(/[-_\s]+/g,"");
        for (var f=0; f<FONTS.length; f++) {
            var af = FONTS[f].replace(/[-_\s]+/g,"");
            if (n.indexOf(af) !== -1 || af.indexOf(n) !== -1) return true;
        }
        return false;
    }

    // =========================================================
    //  HELPERS — GEOMETRY
    // =========================================================
    function nRect(r) {
        if (!r||r.length!==4) return [0,0,0,0];
        var L=parseFloat(r[0]),T=parseFloat(r[1]),R=parseFloat(r[2]),B=parseFloat(r[3]);
        if (!isFinite(L)||!isFinite(T)||!isFinite(R)||!isFinite(B)) return [0,0,0,0];
        return [Math.min(L,R), Math.max(T,B), Math.max(L,R), Math.min(T,B)];
    }

    function overlap(a,b) {
        var na=nRect(a), nb=nRect(b);
        var w=Math.min(na[2],nb[2])-Math.max(na[0],nb[0]);
        var h=Math.min(na[1],nb[1])-Math.max(na[3],nb[3]);
        return (isFinite(w)&&isFinite(h)&&w>0&&h>0) ? w*h : 0;
    }

    function bestBoard(bounds) {
        var best=-1, bestA=0;
        var nb = nRect(bounds);
        for (var a=0; a<doc.artboards.length; a++) {
            try { var ar=overlap(nb, doc.artboards[a].artboardRect); if(ar>bestA){bestA=ar;best=a;} } catch(e){}
        }
        if (best===-1) {
            var cx=(nb[0]+nb[2])/2, cy=(nb[1]+nb[3])/2;
            for (var a2=0; a2<doc.artboards.length; a2++) {
                try {
                    var ar2=nRect(doc.artboards[a2].artboardRect);
                    if (cx>=ar2[0]&&cx<=ar2[2]&&cy<=ar2[1]&&cy>=ar2[3]) { best=a2; break; }
                } catch(e){}
            }
        }
        return best;
    }

    // outside() checks using geometricBounds (actual path, no stroke).
    // This prevents false positives where only the stroke bleeds over the edge.
    // If geometric bounds are fully inside artboard -> NOT flagged.
    // Only flagged when the actual object geometry crosses the artboard edge.
    function outside(geomBounds, artRect) {
        var b=nRect(geomBounds), a=nRect(artRect);
        if ((a[2]-a[0])<=0||(a[1]-a[3])<=0) return true;
        var t=0.5; // 0.5pt tolerance — ignore sub-pixel overflows
        return (b[0]<a[0]-t||b[2]>a[2]+t||b[1]>a[1]+t||b[3]<a[3]-t);
    }

    // Get geometric bounds safely; fall back to visibleBounds if unavailable
    function geomBounds(item) {
        try {
            var gb = item.geometricBounds;
            if (gb && gb.length===4 &&
                isFinite(parseFloat(gb[0])) && isFinite(parseFloat(gb[1])) &&
                isFinite(parseFloat(gb[2])) && isFinite(parseFloat(gb[3]))) {
                return gb;
            }
        } catch(e) {}
        try { return item.visibleBounds; } catch(e2) { return [0,0,0,0]; }
    }

    function resolve(bounds) {
        var idx = bestBoard(bounds);
        var dat = (idx===-1) ? outsideAll : boards[idx];
        var rct = (idx===-1) ? null : doc.artboards[idx].artboardRect;
        var nb  = nRect(bounds);
        if (idx===-1 && ((nb[2]-nb[0])<=0||(nb[1]-nb[3])<=0)) {
            var cx=(nb[0]+nb[2])/2, cy=(nb[1]+nb[3])/2;
            for (var a=0; a<doc.artboards.length; a++) {
                var ar=nRect(doc.artboards[a].artboardRect);
                if (cx>=ar[0]&&cx<=ar[2]&&cy<=ar[1]&&cy>=ar[3]) {
                    idx=a; dat=boards[a]; rct=doc.artboards[a].artboardRect; break;
                }
            }
        }
        return {idx:idx, dat:dat, rct:rct};
    }

    // =========================================================
    //  HELPERS — HTML
    // =========================================================
    function esc(s) {
        if (s===undefined||s===null) return "";
        return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
                        .replace(/"/g,"&quot;").replace(/'/g,"&#39;");
    }

    function renderDS(raw) {
        try {
            raw = (raw===undefined||raw===null) ? "" : String(raw);
            var out="", li=0, re=/ {2,}/g, m;
            while ((m=re.exec(raw))!==null) {
                var s=m.index, l=m[0].length;
                if (s>li) out+=esc(raw.substring(li,s));
                var nb=""; for(var k=0;k<l;k++) nb+="&nbsp;";
                out+='<span class="dsh">'+nb+'</span><small class="dsp">pos:'+s+'</small>';
                li=s+l;
            }
            if (li<raw.length) out+=esc(raw.substring(li));
            return out||esc(raw);
        } catch(e) { return esc(raw); }
    }

    // =========================================================
    //  ARTBOARD SIZE CLASSIFICATION
    //  SM  longest side <  400pt  → min font  8pt
    //  MD  longest side  400-799pt → min font 10pt
    //  L   longest side  800-1199pt → min font 12pt
    //  XL  longest side >= 1200pt  → min font 12pt
    // =========================================================
    function classifyArtboard(artRect) {
        var r = nRect(artRect);
        var w = Math.abs(r[2] - r[0]);
        var h = Math.abs(r[1] - r[3]);
        var longest = w > h ? w : h;
        if (longest < 400)  return {size:"SM", minFont:8};
        if (longest < 800)  return {size:"MD", minFont:10};
        return                     {size:"L/XL", minFont:12};
    }

    // =========================================================
    //  DATA STRUCTURES
    // =========================================================
    function mkBoard(name, idx, artClass) {
        return { name:name, idx:idx,
                 sizeClass: artClass ? artClass.size    : "?",
                 minFont:   artClass ? artClass.minFont : 8,
                 fontIssues:[], dsIssues:[], strokeIssues:[],
                 outsideIssues:[], colorIssues:[], fontNameIssues:[],
                 smallFontIssues:[],
                 trackingIssues:[],   // wrong tracking/kerning
                 scaleIssues:[],      // H or V scale != 100%
                 rotationIssues:[],   // character rotation != 0
                 hasIssues:false };
    }

    var boards = [];
    for (var a=0; a<doc.artboards.length; a++) {
        var abClass = classifyArtboard(doc.artboards[a].artboardRect);
        boards.push(mkBoard(doc.artboards[a].name||("Artboard "+(a+1)), a, abClass));
    }

    var outsideAll   = mkBoard("Outside All Artboards", -1);
    var swatchName   = [];   // bad swatch names
    var swatchColor  = [];   // off-brand swatch colors

    // =========================================================
    //  SCAN — TEXT FRAMES
    // =========================================================
    for (var i=0; i<doc.textFrames.length; i++) {
        try {
            var tf  = doc.textFrames[i];
            if (tf.locked||tf.hidden) continue;
            var txt = String(tf.contents||"");
            var res = resolve(tf.visibleBounds);
            var bd  = res.dat;

            // decimal font sizes (character level)
            var runs=[];
            try {
                var chars=tf.characters, rs=-1, rsz=null;
                for (var c=0; c<chars.length; c++) {
                    var csz;
                    try { csz=chars[c].characterAttributes.size; } catch(e){ csz=tf.textRange.characterAttributes.size; }
                    if (typeof csz==="number" && Math.abs(csz%1)>0.000001) {
                        if (rs===-1){rs=c;rsz=csz;}
                    } else {
                        if (rs!==-1){runs.push({s:rs,e:c-1,sz:rsz});rs=-1;rsz=null;}
                    }
                }
                if (rs!==-1) runs.push({s:rs,e:chars.length-1,sz:rsz});
            } catch(e) {
                try {
                    var fsz=tf.textRange.characterAttributes.size;
                    if (typeof fsz==="number"&&Math.abs(fsz%1)>0.000001)
                        runs.push({s:0,e:txt.length-1,sz:fsz});
                } catch(e2){}
            }
            for (var r=0; r<runs.length; r++) {
                try {
                    var run=runs[r];
                    var si=Math.max(0,Math.min(run.s,txt.length-1));
                    var ei=Math.max(si,Math.min(run.e,txt.length-1));
                    var lb=-1;
                    for(var lx=si-1;lx>=0;lx--){var ch=txt.charAt(lx);if(ch===" "||ch==="\n"||ch==="\t"||ch==="\r"){lb=lx;break;}}
                    var rb=-1;
                    for(var rx=ei+1;rx<txt.length;rx++){var ch2=txt.charAt(rx);if(ch2===" "||ch2==="\n"||ch2==="\t"||ch2==="\r"){rb=rx;break;}}
                    var word=txt.substring(lb===-1?0:lb+1, rb===-1?txt.length:rb).replace(/^\s+|\s+$/g,"");
                    bd.fontIssues.push({sentence:txt, word:word, size:run.sz!==undefined?run.sz.toFixed(2):""});
                    bd.hasIssues=true;
                } catch(e){}
            }

            // double spaces
            try {
                if (txt.match(/ {2,}/)){
                    bd.dsIssues.push({text:txt});
                    bd.hasIssues=true;
                }
            } catch(e){}

            // small font size (per artboard size class threshold)
            try {
                var sfChars = tf.characters;
                var seenSmall = {};
                for (var sc=0; sc<sfChars.length; sc++) {
                    try {
                        var sfSz;
                        try { sfSz = sfChars[sc].characterAttributes.size; }
                        catch(e) { sfSz = tf.textRange.characterAttributes.size; }
                        if (typeof sfSz === "number" && sfSz < bd.minFont) {
                            var sfKey = Math.round(sfSz*100);
                            if (!seenSmall[sfKey]) {
                                seenSmall[sfKey] = true;
                                bd.smallFontIssues.push({
                                    text: txt.substring(0,80),
                                    size: sfSz.toFixed(2),
                                    minFont: bd.minFont,
                                    sizeClass: bd.sizeClass
                                });
                                bd.hasIssues = true;
                            }
                        }
                    } catch(e){}
                }
            } catch(e){}

            // unapproved fonts
            try {
                var chars3=tf.characters, seenF={};
                for(var c3=0;c3<chars3.length;c3++){
                    try {
                        var fn="";
                        try{fn=chars3[c3].characterAttributes.textFont?chars3[c3].characterAttributes.textFont.name:"";}catch(e){}
                        if(fn&&!seenF[fn]){
                            seenF[fn]=true;
                            if(!approvedFont(fn)){
                                bd.fontNameIssues.push({font:fn, sample:txt.substring(0,60)});
                                bd.hasIssues=true;
                            }
                        }
                    } catch(e){}
                }
            } catch(e){}

            // ── TRACKING / KERNING CHECK ──
            // Illustrator stores tracking as trackingUnit on characterAttributes
            // Value is in thousandths of an em (same as the panel display)
            try {
                var trkChars = tf.characters;
                var seenTrk = {};
                for (var tc=0; tc<trkChars.length; tc++) {
                    try {
                        var ca = trkChars[tc].characterAttributes;
                        var trk = ca.tracking; // integer, thousandths of em
                        var expectedTrk = REQUIRED_TRACKING;
                        if (trk !== expectedTrk) {
                            var trkKey = trk + "|" + txt.substring(0,40);
                            if (!seenTrk[trkKey]) {
                                seenTrk[trkKey] = true;
                                bd.trackingIssues.push({
                                    text: txt.substring(0,80),
                                    tracking: trk,
                                    expected: expectedTrk,
                                    brand: brandName
                                });
                                bd.hasIssues = true;
                            }
                        }
                    } catch(e){}
                }
            } catch(e){}

            // ── HORIZONTAL / VERTICAL SCALE CHECK ──
            // Must be 100% for both. Illustrator stores as 0-100+ float.
            try {
                var scChars = tf.characters;
                var seenSc = {};
                for (var sc2=0; sc2<scChars.length; sc2++) {
                    try {
                        var ca2 = scChars[sc2].characterAttributes;
                        var hScale = ca2.horizontalScale; // % e.g. 100
                        var vScale = ca2.verticalScale;
                        var hBad = (Math.abs(hScale - 100) > 0.5);
                        var vBad = (Math.abs(vScale - 100) > 0.5);
                        if (hBad || vBad) {
                            var scKey = hScale.toFixed(1)+"|"+vScale.toFixed(1)+"|"+txt.substring(0,40);
                            if (!seenSc[scKey]) {
                                seenSc[scKey] = true;
                                bd.scaleIssues.push({
                                    text: txt.substring(0,80),
                                    hScale: hScale.toFixed(1),
                                    vScale: vScale.toFixed(1)
                                });
                                bd.hasIssues = true;
                            }
                        }
                    } catch(e){}
                }
            } catch(e){}

            // ── CHARACTER ROTATION CHECK ──
            // Must be 0 degrees. Stored as float on characterAttributes.
            try {
                var rotChars = tf.characters;
                var seenRot = {};
                for (var rc=0; rc<rotChars.length; rc++) {
                    try {
                        var ca3 = rotChars[rc].characterAttributes;
                        var rot = ca3.rotation; // degrees
                        if (Math.abs(rot) > 0.1) {
                            var rotKey = rot.toFixed(1)+"|"+txt.substring(0,40);
                            if (!seenRot[rotKey]) {
                                seenRot[rotKey] = true;
                                bd.rotationIssues.push({
                                    text: txt.substring(0,80),
                                    rotation: rot.toFixed(1)
                                });
                                bd.hasIssues = true;
                            }
                        }
                    } catch(e){}
                }
            } catch(e){}

            // outside artboard — check against geometricBounds, crop screenshot from visibleBounds
            if(res.idx===-1){
                bd.outsideIssues.push({type:"TextFrame (no overlap)", bounds:tf.visibleBounds});
                bd.hasIssues=true;
            } else if(res.rct && outside(geomBounds(tf), res.rct)){
                bd.outsideIssues.push({type:"TextFrame", bounds:tf.visibleBounds});
                bd.hasIssues=true;
            }

        } catch(e){}
    }

    // =========================================================
    //  SCAN — PAGE ITEMS
    // =========================================================
    for (var j=0; j<doc.pageItems.length; j++) {
        try {
            var it = doc.pageItems[j];
            if (it.locked||it.hidden||it.guides||it.typename==="TextFrame") continue;
            var res2 = resolve(it.visibleBounds);
            var bd2  = res2.dat;

            // stroke width
            if (it.stroked) {
                var sw = it.strokeWidth;
                if (!validStroke(sw)){ bd2.strokeIssues.push({type:it.typename, width:sw.toFixed(2)}); bd2.hasIssues=true; }
            }

            // off-brand fill
            try {
                if (it.filled) {
                    var rgb = colorToRGB(it.fillColor);
                    if (rgb && !approvedColor(rgb[0],rgb[1],rgb[2])){
                        bd2.colorIssues.push({type:it.typename, rgb:rgb, hex:toHex(rgb[0],rgb[1],rgb[2])});
                        bd2.hasIssues=true;
                    }
                }
            } catch(e){}

            // outside — check against geometricBounds, crop screenshot from visibleBounds
            if(res2.idx===-1){
                bd2.outsideIssues.push({type:it.typename+" (no overlap)", bounds:it.visibleBounds});
                bd2.hasIssues=true;
            } else if(res2.rct && outside(geomBounds(it), res2.rct)){
                bd2.outsideIssues.push({type:it.typename, bounds:it.visibleBounds});
                bd2.hasIssues=true;
            }

        } catch(e){}
    }

    // =========================================================
    //  SCAN — SWATCHES
    // =========================================================
    for (var s=0; s<doc.swatches.length; s++) {
        try {
            var sw2 = doc.swatches[s];
            if (badSwatchName(sw2)) swatchName.push({name:sw2.name, idx:s+1});
            var rgb3 = colorToRGB(sw2.color);
            if (rgb3) {
                var sn = sw2.name.toLowerCase();
                if (sn==="[none]"||sn==="[registration]"||sn==="[black]"||sn==="[paper]"||sn==="[white]") continue;
                if (!approvedColor(rgb3[0],rgb3[1],rgb3[2]))
                    swatchColor.push({name:sw2.name, idx:s+1, rgb:rgb3, hex:toHex(rgb3[0],rgb3[1],rgb3[2])});
            }
        } catch(e){}
    }

    // =========================================================
    //  CAPTURE — crop-export each outside object individually
    // =========================================================

    // Base64 encoder (ExtendScript has no native btoa)
    function btoa64(bin) {
        var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        var out = "", ix = 0, len = bin.length;
        while (ix < len) {
            var b0 = bin.charCodeAt(ix++) & 0xFF;
            var b1 = ix < len ? bin.charCodeAt(ix++) & 0xFF : 0;
            var b2 = ix < len ? bin.charCodeAt(ix++) & 0xFF : 0;
            var n24 = (b0 << 16) | (b1 << 8) | b2;
            out += chars[(n24>>18)&63]+chars[(n24>>12)&63]+chars[(n24>>6)&63]+chars[n24&63];
        }
        var pad = (3 - (len % 3)) % 3;
        return out.substring(0, out.length - pad) + "==".substring(0, pad);
    }

    // Export a crop-region PNG centred on the given bounds, with padding
    // bounds = [left, top, right, bottom] in Illustrator pts (Y flipped)
    function cropExport(bounds) {
        try {
            var PAD = 30; // pt padding around object
            var L = parseFloat(bounds[0]) - PAD;
            var T = parseFloat(bounds[1]) + PAD;
            var R = parseFloat(bounds[2]) + PAD;
            var B = parseFloat(bounds[3]) - PAD;
            var W = R - L;
            var H = T - B;
            if (W <= 0 || H <= 0) return null;

            // Create a temporary artboard sized to the crop region
            var origABCount = doc.artboards.length;
            var tmpAB = doc.artboards.add([L, T, R, B]);
            var tmpABIdx = doc.artboards.length - 1;
            doc.artboards.setActiveArtboardIndex(tmpABIdx);

            // Export that artboard
            var ts = (new Date()).getTime();
            var tmpBase = new File(Folder.temp + "/brix_obj_" + ts);
            var opts = new ExportOptionsPNG24();
            opts.artBoardClipping = true;
            opts.antiAliasing = true;
            opts.transparency = true;
            opts.resolution = 144; // 2x for sharpness
            doc.exportFile(tmpBase, ExportType.PNG24, opts);

            // Remove temp artboard
            try { tmpAB.remove(); } catch(e){}

            // Illustrator names the file: basename + "_" + (index+1 zero-padded) + ".png"
            // Try suffixed first, then unsuffixed
            var suffix = tmpABIdx + 1;
            var pad = suffix < 10 ? "0" + suffix : String(suffix);
            var candidates = [
                new File(tmpBase.fsName + "_" + pad + ".png"),
                new File(tmpBase.fsName + ".png")
            ];
            var pngFile = null;
            for (var ci = 0; ci < candidates.length; ci++) {
                if (candidates[ci].exists) { pngFile = candidates[ci]; break; }
            }
            if (!pngFile) return null;

            pngFile.encoding = "BINARY";
            if (!pngFile.open("r")) return null;
            var raw = pngFile.read();
            pngFile.close();
            try { pngFile.remove(); } catch(e){}
            return btoa64(raw);
        } catch(e) { return null; }
    }

    // Capture one PNG per outside issue (stores base64 back into the issue object)
    var allOutsideIssues = [];
    for (var cap_i = 0; cap_i < boards.length; cap_i++) {
        for (var cap_j = 0; cap_j < boards[cap_i].outsideIssues.length; cap_j++) {
            allOutsideIssues.push(boards[cap_i].outsideIssues[cap_j]);
        }
    }
    for (var cap_k = 0; cap_k < outsideAll.outsideIssues.length; cap_k++) {
        allOutsideIssues.push(outsideAll.outsideIssues[cap_k]);
    }
    for (var cap_m = 0; cap_m < allOutsideIssues.length; cap_m++) {
        var iss = allOutsideIssues[cap_m];
        if (iss.bounds) {
            iss.shot = cropExport(iss.bounds);
        }
    }

    // =========================================================
    //  TOTALS
    // =========================================================
    var boardsWithIssues=0;
    var tFonts=0, tDS=0, tStrokes=0, tOutside=0, tColors=0, tBadFonts=0, tSmallFonts=0;
    var tTracking=0, tScale=0, tRotation=0;
    for(var t=0;t<boards.length;t++){
        if(boards[t].hasIssues) boardsWithIssues++;
        tFonts      += boards[t].fontIssues.length;
        tDS         += boards[t].dsIssues.length;
        tStrokes    += boards[t].strokeIssues.length;
        tOutside    += boards[t].outsideIssues.length;
        tColors     += boards[t].colorIssues.length;
        tBadFonts   += boards[t].fontNameIssues.length;
        tSmallFonts += boards[t].smallFontIssues.length;
        tTracking   += boards[t].trackingIssues.length;
        tScale      += boards[t].scaleIssues.length;
        tRotation   += boards[t].rotationIssues.length;
    }
    var tSwName  = swatchName.length;
    var tSwColor = swatchColor.length;
    var tAll     = tFonts+tDS+tStrokes+tOutside+tColors+tBadFonts+tSmallFonts+tTracking+tScale+tRotation+tSwName+tSwColor;
    var isPass   = (tAll===0 && !fileNameHasIssue);
    var scanDate = (new Date()).toString();

    // =========================================================
    //  BUILD HTML
    // =========================================================
    var P = [];

    // ── head ──
    P.push('<!doctype html><html lang="en"><head>');
    P.push('<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">');
    P.push('<title>Brix QC — '+esc(docName)+'</title>');
    P.push('<style>');

    // reset + vars
    P.push('*{box-sizing:border-box;margin:0;padding:0;}');
    P.push(':root{--bg:#f0f2f7;--panel:#fff;--border:#e2e6ed;--muted:#8a919e;');
    P.push('--primary:#6C5CE7;--primary-lt:#ede9fd;--primary-dk:#5649c0;');
    P.push('--red:#e03e3e;--red-lt:#fff5f5;--red-bd:#fcc;');
    P.push('--blue:#2d8cf0;--blue-lt:#f0f7ff;--blue-bd:#bdd9f9;');
    P.push('--gold:#d4890a;--gold-lt:#fffbf0;--gold-bd:#fde8a0;');
    P.push('--purple:#9b51e0;--purple-lt:#f9f0ff;--purple-bd:#dbbdfc;');
    P.push('--orange:#d4580a;--orange-lt:#fff7f0;--orange-bd:#fcc9a0;');
    P.push('--green:#00a854;--green-lt:#f0fdf6;--green-bd:#9de8bd;');
    P.push('--radius:10px;--shadow:0 2px 10px rgba(0,0,0,0.07);}');

    // typography
    P.push('body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;');
    P.push('background:var(--bg);color:#1a1f2e;font-size:14px;line-height:1.55;}');

    // topbar
    P.push('.topbar{position:sticky;top:0;z-index:200;height:56px;background:#fff;');
    P.push('border-bottom:1px solid var(--border);display:grid;');
    P.push('grid-template-columns:1fr auto 1fr;align-items:center;padding:0 24px;');
    P.push('box-shadow:0 1px 3px rgba(0,0,0,0.06);}');
    P.push('.tl{display:flex;align-items:center;gap:14px;}');
    P.push('.logo{font-weight:800;font-size:1rem;color:var(--primary);letter-spacing:-0.3px;white-space:nowrap;}');
    P.push('.logo b{color:#1a1f2e;}');
    P.push('.doc-name{font-size:1.05rem;font-weight:800;color:#1a1f2e;letter-spacing:-0.02em;');
    P.push('text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:0 16px;}');
    P.push('.tr{display:flex;align-items:center;gap:8px;justify-content:flex-end;}');
    P.push('.pill{display:inline-flex;align-items:center;padding:3px 11px;border-radius:999px;');
    P.push('font-size:0.72rem;font-weight:700;letter-spacing:0.04em;}');
    P.push('.pill-brand{background:var(--primary);color:#fff;}');
    P.push('.pill-pass{background:var(--green-lt);color:var(--green);border:1px solid var(--green-bd);}');
    P.push('.pill-fail{background:var(--red-lt);color:var(--red);border:1px solid var(--red-bd);}');
    P.push('.pill-warn{background:#fff8e6;color:#b06d00;border:1px solid #f5d48a;}');

    // layout
    P.push('.layout{display:flex;min-height:calc(100vh - 56px);}');

    // sidebar
    P.push('.sidebar{width:220px;flex-shrink:0;background:#fff;border-right:1px solid var(--border);');
    P.push('padding:12px 0;position:sticky;top:56px;height:calc(100vh - 56px);overflow-y:auto;}');
    P.push('.sb-label{padding:10px 16px 4px;font-size:0.68rem;font-weight:700;');
    P.push('text-transform:uppercase;letter-spacing:0.1em;color:var(--muted);}');
    P.push('.sb-btn{width:100%;text-align:left;border:none;background:none;cursor:pointer;');
    P.push('padding:7px 16px;font-size:0.83rem;color:#1a1f2e;font-family:inherit;');
    P.push('display:flex;align-items:center;justify-content:space-between;gap:6px;');
    P.push('transition:background 0.1s;}');
    P.push('.sb-btn:hover{background:var(--bg);}');
    P.push('.sb-btn.active{background:var(--primary-lt);color:var(--primary);font-weight:600;}');
    P.push('.sb-row{display:flex;align-items:center;gap:7px;min-width:0;}');
    P.push('.sb-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0;}');
    P.push('.sb-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}');
    P.push('.sb-count{font-size:0.68rem;font-weight:700;padding:1px 6px;border-radius:999px;');
    P.push('flex-shrink:0;background:var(--bg);color:var(--muted);}');
    P.push('.sb-count.hot{background:#ffeaea;color:var(--red);}');

    // main
    P.push('.main{flex:1;padding:24px 28px 60px;min-width:0;max-width:960px;}');
    P.push('.page{display:none;animation:fadeUp 0.18s ease;}');
    P.push('.page.on{display:block;}');
    P.push('@keyframes fadeUp{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}');

    // page title
    P.push('.pg-title{margin-bottom:20px;}');
    P.push('.pg-title h2{font-size:1.15rem;font-weight:800;color:#1a1f2e;}');
    P.push('.pg-title p{font-size:0.8rem;color:var(--muted);margin-top:3px;}');

    // KPI grid
    P.push('.kpi-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-bottom:20px;}');
    P.push('.kpi{background:#fff;border:1px solid var(--border);border-radius:var(--radius);');
    P.push('padding:14px 16px;cursor:pointer;transition:box-shadow 0.15s,border-color 0.15s;}');
    P.push('.kpi:hover{box-shadow:var(--shadow);border-color:#c8cdd8;}');
    P.push('.kpi-n{font-size:1.9rem;font-weight:800;line-height:1;color:var(--primary);}');
    P.push('.kpi-n.ok{color:var(--green);}');
    P.push('.kpi-l{font-size:0.72rem;color:var(--muted);margin-top:4px;text-transform:uppercase;letter-spacing:0.06em;}');
    P.push('.kpi-bar{height:3px;border-radius:2px;margin-top:8px;background:var(--border);}');
    P.push('.kpi-fill{height:100%;border-radius:2px;background:var(--primary);transition:width .6s ease;}');
    P.push('.kpi-fill.ok{background:var(--green);}');

    // breakdown chart
    P.push('.bdown{background:#fff;border:1px solid var(--border);border-radius:var(--radius);');
    P.push('padding:16px 18px;margin-bottom:20px;}');
    P.push('.bdown-title{font-size:0.82rem;font-weight:700;color:#1a1f2e;margin-bottom:12px;}');
    P.push('.br{display:flex;align-items:center;gap:10px;margin-bottom:7px;}');
    P.push('.br-label{width:138px;font-size:0.78rem;color:var(--muted);text-align:right;flex-shrink:0;}');
    P.push('.br-track{flex:1;height:8px;background:var(--bg);border-radius:99px;overflow:hidden;}');
    P.push('.br-fill{height:100%;border-radius:99px;transition:width .7s ease;}');
    P.push('.br-n{width:26px;text-align:right;font-size:0.75rem;font-weight:700;flex-shrink:0;}');

    // artboard summary rows
    P.push('.ab-summary{background:#fff;border:1px solid var(--border);border-radius:var(--radius);');
    P.push('overflow:hidden;margin-bottom:8px;cursor:pointer;transition:box-shadow 0.15s;}');
    P.push('.ab-summary:hover{box-shadow:var(--shadow);}');
    P.push('.ab-row{display:flex;align-items:center;justify-content:space-between;padding:11px 14px;gap:10px;}');
    P.push('.ab-left{display:flex;align-items:center;gap:8px;min-width:0;}');
    P.push('.ab-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}');
    P.push('.ab-name{font-weight:700;font-size:0.88rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}');
    P.push('.ab-count{font-size:0.78rem;color:var(--muted);margin-left:6px;flex-shrink:0;}');
    P.push('.ab-chips{display:flex;gap:5px;flex-wrap:wrap;flex-shrink:0;}');

    // chips
    P.push('.chip{display:inline-flex;align-items:center;padding:2px 8px;border-radius:999px;');
    P.push('font-size:0.68rem;font-weight:700;border:1px solid transparent;white-space:nowrap;}');
    P.push('.chip-clean{background:var(--green-lt);color:var(--green);border-color:var(--green-bd);}');
    P.push('.chip-fonts{background:var(--red-lt);color:var(--red);border-color:var(--red-bd);}');
    P.push('.chip-ds{background:var(--blue-lt);color:var(--blue);border-color:var(--blue-bd);}');
    P.push('.chip-stroke{background:var(--gold-lt);color:var(--gold);border-color:var(--gold-bd);}');
    P.push('.chip-out{background:var(--purple-lt);color:var(--purple);border-color:var(--purple-bd);}');
    P.push('.chip-color{background:var(--orange-lt);color:var(--orange);border-color:var(--orange-bd);}');
    P.push('.chip-bfont{background:var(--purple-lt);color:var(--purple);border-color:var(--purple-bd);}');

    // collapsible section cards
    P.push('.sec{background:#fff;border:1px solid var(--border);border-radius:var(--radius);margin-bottom:10px;overflow:hidden;}');
    P.push('.sec-hd{display:flex;align-items:center;justify-content:space-between;padding:11px 14px;');
    P.push('cursor:pointer;user-select:none;gap:10px;}');
    P.push('.sec-hd:hover{background:#fafbfc;}');
    P.push('.sec-left{display:flex;align-items:center;gap:8px;}');
    P.push('.sec-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}');
    P.push('.sec-title{font-size:0.88rem;font-weight:700;}');
    P.push('.sec-right{display:flex;align-items:center;gap:8px;flex-shrink:0;}');
    P.push('.sec-chev{font-size:0.7rem;color:var(--muted);transition:transform 0.2s;display:inline-block;}');
    P.push('.sec-body{display:none;border-top:1px solid var(--border);padding:12px 14px;}');
    P.push('.sec-body.open{display:block;}');
    P.push('.sec-hd.open .sec-chev{transform:rotate(180deg);}');

    // item grid
    P.push('.items{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:7px;margin-top:4px;}');
    P.push('.item{border-radius:8px;padding:9px 11px;border:1px solid var(--border);background:var(--bg);font-size:0.82rem;}');
    P.push('.item-title{font-weight:700;display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:2px;word-break:break-word;}');
    P.push('.item-meta{color:var(--muted);font-size:0.76rem;word-break:break-word;}');
    P.push('.item.red{border-left:3px solid var(--red);background:var(--red-lt);}');
    P.push('.item.blue{border-left:3px solid var(--blue);background:var(--blue-lt);}');
    P.push('.item.gold{border-left:3px solid var(--gold);background:var(--gold-lt);}');
    P.push('.item.purple{border-left:3px solid var(--purple);background:var(--purple-lt);}');
    P.push('.item.orange{border-left:3px solid var(--orange);background:var(--orange-lt);}');
    P.push('.ok-msg{font-style:italic;color:var(--green);font-size:0.82rem;padding:2px 0;}');

    // swatch dot
    P.push('.sw-dot{display:inline-block;width:10px;height:10px;border-radius:2px;');
    P.push('border:1px solid rgba(0,0,0,0.12);flex-shrink:0;}');

    // double space highlight
    P.push('.dsh{background:#c8e6ff;padding:1px 4px;border-radius:3px;font-weight:700;font-family:monospace;}');
    P.push('.dsp{margin-left:4px;font-size:0.7rem;color:var(--muted);}');

    // search / filter
    P.push('.search-bar{display:flex;gap:8px;align-items:center;margin-bottom:14px;flex-wrap:wrap;}');
    P.push('.search-input{flex:1;min-width:160px;padding:7px 11px;border:1px solid var(--border);');
    P.push('border-radius:7px;font-size:0.85rem;font-family:inherit;outline:none;background:#fff;}');
    P.push('.search-input:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(108,92,231,0.1);}');
    P.push('.filter-wrap{display:flex;gap:5px;flex-wrap:wrap;}');
    P.push('.f-btn{padding:6px 12px;border:1px solid var(--border);border-radius:7px;background:#fff;');
    P.push('font-size:0.76rem;font-weight:600;cursor:pointer;color:var(--muted);font-family:inherit;');
    P.push('transition:all 0.12s;}');
    P.push('.f-btn:hover{border-color:#c8cdd8;color:#1a1f2e;}');
    P.push('.f-btn.on{background:var(--primary);color:#fff;border-color:var(--primary);}');
    P.push('.search-hint{font-size:0.76rem;color:var(--muted);}');

    // footer
    P.push('.footer{text-align:center;font-size:0.76rem;color:var(--muted);');
    P.push('padding:20px 0;border-top:1px solid var(--border);margin-top:16px;}');

    P.push('</style></head><body>');

    // ── TOPBAR ──
    P.push('<div class="topbar">');
    P.push('<div class="tl"><div class="logo">Brix <b>QC</b></div></div>');
    P.push('<div class="doc-name" style="'+(fileNameHasIssue?'color:var(--orange);':'')+'">'+esc(docName)+(fileNameHasIssue?' <span style="font-size:0.8rem">⚠</span>':'')+' </div>');
    P.push('<div class="tr">');
    P.push('<span class="pill pill-brand">'+esc(brandName)+'</span>');
    P.push('<span class="pill '+(isPass?'pill-pass':'pill-fail')+'">'+(isPass?'✓ PASS':'✗ ISSUES')+'</span>');
    if (fileNameHasIssue) {
        P.push('<span class="pill pill-warn" title="Filename contains special characters: '+foundBadChars.join(' ')+'">⚠ Filename</span>');
    }
    P.push('</div></div>');

    // ── LAYOUT ──
    P.push('<div class="layout">');

    // ── SIDEBAR ──
    P.push('<nav class="sidebar">');
    P.push('<div class="sb-label">Overview</div>');
    P.push('<button class="sb-btn active" onclick="nav(\'dash\',this)">');
    P.push('<div class="sb-row"><span class="sb-dot" style="background:'+(isPass?'var(--green)':'var(--red)')+'"></span>');
    P.push('<span class="sb-name">Dashboard</span></div>');
    P.push('<span class="sb-count '+(tAll>0?'hot':'')+'">'+tAll+'</span></button>');

    P.push('<div class="sb-label" style="margin-top:6px">Swatches</div>');
    var swT = tSwName+tSwColor;
    P.push('<button class="sb-btn" onclick="nav(\'swatches\',this)">');
    P.push('<div class="sb-row"><span class="sb-dot" style="background:'+(swT>0?'var(--red)':'var(--green)')+'"></span>');
    P.push('<span class="sb-name">Swatches</span></div>');
    P.push('<span class="sb-count '+(swT>0?'hot':'')+'">'+swT+'</span></button>');

    P.push('<div class="sb-label" style="margin-top:6px">Artboards</div>');
    for (var nb=0; nb<boards.length; nb++) {
        var bd3=boards[nb];
        var bt=bd3.fontIssues.length+bd3.dsIssues.length+bd3.strokeIssues.length+bd3.outsideIssues.length+bd3.colorIssues.length+bd3.fontNameIssues.length+
            (bd3.smallFontIssues?bd3.smallFontIssues.length:0)+
            (bd3.trackingIssues?bd3.trackingIssues.length:0)+
            (bd3.scaleIssues?bd3.scaleIssues.length:0)+
            (bd3.rotationIssues?bd3.rotationIssues.length:0);
        P.push('<button class="sb-btn" onclick="nav(\'ab'+nb+'\',this)">');
        P.push('<div class="sb-row"><span class="sb-dot" style="background:'+(bd3.hasIssues?'var(--red)':'var(--green)')+'"></span>');
        P.push('<span class="sb-name">'+esc(bd3.name.length>18?bd3.name.substring(0,16)+'…':bd3.name)+'</span>');
        P.push('<span style="font-size:0.6rem;color:var(--muted);margin-left:3px;flex-shrink:0;">'+esc(bd3.sizeClass)+'</span></div>');
        P.push('<span class="sb-count '+(bt>0?'hot':'')+'">'+bt+'</span></button>');
    }
    if (outsideAll.hasIssues) {
        P.push('<button class="sb-btn" onclick="nav(\'outside\',this)">');
        P.push('<div class="sb-row"><span class="sb-dot" style="background:var(--red)"></span>');
        P.push('<span class="sb-name">Outside All</span></div>');
        P.push('<span class="sb-count hot">'+outsideAll.outsideIssues.length+'</span></button>');
    }
    P.push('</nav>');

    // ── MAIN ──
    P.push('<main class="main">');

    // ========================================================
    //  PAGE: DASHBOARD
    // ========================================================
    P.push('<div class="page on" id="p-dash">');
    P.push('<div class="pg-title"><h2>Dashboard</h2>');
    P.push('<p>'+esc(scanDate)+' &nbsp;·&nbsp; QC: <strong>'+esc(qcUser)+'</strong></p></div>');

    // Filename issue banner
    if (fileNameHasIssue) {
        P.push('<div style="background:#fff8e6;border:1px solid #f5d48a;border-left:4px solid #d4890a;');
        P.push('border-radius:var(--radius);padding:12px 16px;margin-bottom:16px;display:flex;align-items:flex-start;gap:10px;">');
        P.push('<span style="font-size:1.1rem;flex-shrink:0;">⚠</span>');
        P.push('<div><div style="font-weight:700;font-size:0.88rem;color:#7a4800;margin-bottom:3px;">Filename contains special characters</div>');
        P.push('<div style="font-size:0.82rem;color:#7a4800;">');
        P.push('<strong>'+esc(docName)+'</strong><br>');
        P.push('Found: <code style="background:rgba(0,0,0,0.06);padding:1px 5px;border-radius:3px;">'+esc(foundBadChars.join('  '))+'</code><br>');
        P.push('<span style="opacity:0.75">Use only letters, numbers and spaces in filenames.</span>');
        P.push('</div></div></div>');
    }

    // KPI cards
    var maxV = Math.max(tFonts,tDS,tStrokes,tOutside,tColors,tBadFonts,tSwName+tSwColor,1);
    var kpis = [
        {n:boards.length,  l:"Artboards",       ok:true,          page:""},
        {n:boardsWithIssues, l:"With Issues",    ok:boardsWithIssues===0, page:""},
        {n:tSwName+tSwColor, l:"Swatch Issues",  ok:tSwName+tSwColor===0, page:"swatches"},
        {n:tFonts,         l:"Decimal Fonts",    ok:tFonts===0,    page:""},
        {n:tDS,            l:"Double Spaces",    ok:tDS===0,       page:""},
        {n:tStrokes,       l:"Stroke Issues",    ok:tStrokes===0,  page:""},
        {n:tOutside,       l:"Outside Artboard", ok:tOutside===0,  page:""},
        {n:tColors,        l:"Off-Brand Colors", ok:tColors===0,   page:""},
        {n:tBadFonts,      l:"Unapproved Fonts", ok:tBadFonts===0, page:""},
        {n:tSmallFonts,    l:"Small Fonts",       ok:tSmallFonts===0,  page:""},
        {n:tTracking,      l:"Tracking/Kerning",  ok:tTracking===0,    page:""},
        {n:tScale,         l:"Scale ≠ 100%",      ok:tScale===0,       page:""},
        {n:tRotation,      l:"Char Rotation",     ok:tRotation===0,    page:""}
    ];
    P.push('<div class="kpi-grid">');
    for (var ki=0; ki<kpis.length; ki++) {
        var kp=kpis[ki];
        var pct=kp.ok?100:Math.min(100,Math.max(4,Math.round((kp.n/maxV)*100)));
        var oc=kp.page?'onclick="nav(\''+kp.page+'\',document.querySelector(\'.sb-btn[onclick*=\\\"'+kp.page+'\\\"]\'))"':'';
        P.push('<div class="kpi" '+oc+'>');
        P.push('<div class="kpi-n'+(kp.ok?' ok':'')+'">'+kp.n+'</div>');
        P.push('<div class="kpi-l">'+kp.l+'</div>');
        P.push('<div class="kpi-bar"><div class="kpi-fill'+(kp.ok?' ok':'')+'" style="width:'+pct+'%"></div></div>');
        P.push('</div>');
    }
    P.push('</div>');

    // breakdown bars
    var bars = [
        {l:"Decimal Fonts",    n:tFonts,  c:"#e03e3e"},
        {l:"Double Spaces",    n:tDS,     c:"#2d8cf0"},
        {l:"Stroke Issues",    n:tStrokes,c:"#d4890a"},
        {l:"Outside Artboard", n:tOutside,c:"#9b51e0"},
        {l:"Off-Brand Colors", n:tColors, c:"#d4580a"},
        {l:"Unapproved Fonts", n:tBadFonts,  c:"#9b51e0"},
        {l:"Small Fonts",      n:tSmallFonts, c:"#d4890a"},
        {l:"Swatch Naming",    n:tSwName,     c:"#e03e3e"},
        {l:"Tracking/Kerning", n:tTracking,   c:"#e03e3e"},
        {l:"Scale (H/V)",      n:tScale,      c:"#d4890a"},
        {l:"Char Rotation",    n:tRotation,   c:"#d4890a"},
        {l:"Off-Brand Swatches",n:tSwColor,c:"#d4580a"}
    ];
    var bmax=1; for(var bi4=0;bi4<bars.length;bi4++) if(bars[bi4].n>bmax) bmax=bars[bi4].n;
    P.push('<div class="bdown"><div class="bdown-title">Issue Breakdown</div>');
    for (var bi5=0; bi5<bars.length; bi5++) {
        var br=bars[bi5];
        var bpct=br.n===0?0:Math.max(3,Math.round((br.n/bmax)*100));
        P.push('<div class="br">');
        P.push('<div class="br-label">'+br.l+'</div>');
        P.push('<div class="br-track"><div class="br-fill" style="width:'+bpct+'%;background:'+br.c+'"></div></div>');
        P.push('<div class="br-n">'+br.n+'</div>');
        P.push('</div>');
    }
    P.push('</div>');

    // artboard summary rows
    P.push('<div style="font-size:0.72rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--muted);margin-bottom:8px">Artboards</div>');
    for (var ov=0; ov<boards.length; ov++) {
        var ovd=boards[ov];
        var ovt=ovd.fontIssues.length+ovd.dsIssues.length+ovd.strokeIssues.length+ovd.outsideIssues.length+ovd.colorIssues.length+ovd.fontNameIssues.length+
            (ovd.smallFontIssues?ovd.smallFontIssues.length:0)+
            (ovd.trackingIssues?ovd.trackingIssues.length:0)+
            (ovd.scaleIssues?ovd.scaleIssues.length:0)+
            (ovd.rotationIssues?ovd.rotationIssues.length:0);
        P.push('<div class="ab-summary" onclick="nav(\'ab'+ov+'\',document.querySelectorAll(\'.sb-btn\')['+(ov+2)+'])">');
        P.push('<div class="ab-row">');
        P.push('<div class="ab-left"><span class="ab-dot" style="background:'+(ovd.hasIssues?'var(--red)':'var(--green)')+'"></span>');
        P.push('<span class="ab-name">'+esc(ovd.name)+'</span>');
        P.push('<span class="ab-count">'+ovt+' issue'+(ovt!==1?'s':'')+'</span></div>');
        P.push('<div class="ab-chips">');
        if(ovd.fontIssues.length>0) P.push('<span class="chip chip-fonts">'+ovd.fontIssues.length+' fonts</span>');
        if(ovd.dsIssues.length>0) P.push('<span class="chip chip-ds">'+ovd.dsIssues.length+' spaces</span>');
        if(ovd.strokeIssues.length>0) P.push('<span class="chip chip-stroke">'+ovd.strokeIssues.length+' strokes</span>');
        if(ovd.outsideIssues.length>0) P.push('<span class="chip chip-out">'+ovd.outsideIssues.length+' outside</span>');
        if(ovd.colorIssues.length>0) P.push('<span class="chip chip-color">'+ovd.colorIssues.length+' colors</span>');
        if(ovd.fontNameIssues.length>0) P.push('<span class="chip chip-bfont">'+ovd.fontNameIssues.length+' fonts</span>');
        if(ovd.smallFontIssues.length>0) P.push('<span class="chip chip-stroke">'+ovd.smallFontIssues.length+' small</span>');
        if(ovd.trackingIssues.length>0) P.push('<span class="chip chip-fonts">'+ovd.trackingIssues.length+' tracking</span>');
        if(ovd.scaleIssues.length>0) P.push('<span class="chip chip-stroke">'+ovd.scaleIssues.length+' scale</span>');
        if(ovd.rotationIssues.length>0) P.push('<span class="chip chip-stroke">'+ovd.rotationIssues.length+' rotation</span>');
        if(!ovd.hasIssues) P.push('<span class="chip chip-clean">✓ Clean</span>');
        P.push('</div></div></div>');
    }
    P.push('</div>'); // end p-dash

    // ========================================================
    //  PAGE: SWATCHES
    // ========================================================
    P.push('<div class="page" id="p-swatches">');
    P.push('<div class="pg-title"><h2>Swatches</h2><p>Naming issues and off-brand color values</p></div>');

    // naming issues
    P.push('<div class="sec">');
    P.push('<div class="sec-hd'+(tSwName>0?' open':'')+'" onclick="tog(this)">');
    P.push('<div class="sec-left"><span class="sec-dot" style="background:'+(tSwName>0?'var(--red)':'var(--green)')+'"></span>');
    P.push('<span class="sec-title">Swatch Naming Issues</span></div>');
    P.push('<div class="sec-right"><span class="chip '+(tSwName>0?'chip-fonts':'chip-clean')+'">'+tSwName+'</span><span class="sec-chev">▼</span></div></div>');
    P.push('<div class="sec-body'+(tSwName>0?' open':'')+'">');
    if(tSwName===0){ P.push('<div class="ok-msg">✓ All swatches properly named.</div>'); }
    else {
        P.push('<div class="items">');
        for(var si=0;si<swatchName.length;si++){
            P.push('<div class="item red"><div class="item-title">'+(si+1)+'. '+esc(swatchName[si].name)+'</div>');
            P.push('<div class="item-meta">Panel position: '+swatchName[si].idx+'</div></div>');
        }
        P.push('</div>');
    }
    P.push('</div></div>');

    // off-brand swatches
    P.push('<div class="sec">');
    P.push('<div class="sec-hd'+(tSwColor>0?' open':'')+'" onclick="tog(this)">');
    P.push('<div class="sec-left"><span class="sec-dot" style="background:'+(tSwColor>0?'var(--orange)':'var(--green)')+'"></span>');
    P.push('<span class="sec-title">Off-Brand Swatch Colors</span></div>');
    P.push('<div class="sec-right"><span class="chip '+(tSwColor>0?'chip-color':'chip-clean')+'">'+tSwColor+'</span><span class="sec-chev">▼</span></div></div>');
    P.push('<div class="sec-body'+(tSwColor>0?' open':'')+'">');
    if(tSwColor===0){ P.push('<div class="ok-msg">✓ All swatch colors match the '+esc(brandName)+' palette.</div>'); }
    else {
        P.push('<div class="items">');
        for(var sci=0;sci<swatchColor.length;sci++){
            var sc=swatchColor[sci];
            P.push('<div class="item orange"><div class="item-title"><span class="sw-dot" style="background:'+sc.hex+'"></span>'+(sci+1)+'. '+esc(sc.name)+'</div>');
            P.push('<div class="item-meta">Not in '+esc(brandName)+' palette<br>RGB '+sc.rgb[0]+' '+sc.rgb[1]+' '+sc.rgb[2]+'&ensp;'+sc.hex+'</div></div>');
        }
        P.push('</div>');
    }
    P.push('</div></div>');
    P.push('</div>'); // end p-swatches

    // ========================================================
    //  PAGES: PER ARTBOARD
    // ========================================================
    for (var ai=0; ai<boards.length; ai++) {
        var d=boards[ai];
        var dFonts=d.fontIssues.length, dDS=d.dsIssues.length;
        var dSt=d.strokeIssues.length, dOut=d.outsideIssues.length;
        var dCol=d.colorIssues.length, dBF=d.fontNameIssues.length;
        var dTotal=dFonts+dDS+dSt+dOut+dCol+dBF+
            (d.smallFontIssues?d.smallFontIssues.length:0)+
            (d.trackingIssues?d.trackingIssues.length:0)+
            (d.scaleIssues?d.scaleIssues.length:0)+
            (d.rotationIssues?d.rotationIssues.length:0);

        P.push('<div class="page" id="p-ab'+ai+'">');
        P.push('<div class="pg-title"><h2>'+esc(d.name)+'<span style="font-size:0.7rem;font-weight:600;background:var(--primary-lt);color:var(--primary);padding:2px 9px;border-radius:999px;vertical-align:middle;margin-left:10px;">'+esc(d.sizeClass)+' · min '+d.minFont+'pt</span></h2><p>'+dTotal+' issue'+(dTotal!==1?'s':'')+'</p></div>');

        if (!d.hasIssues) {
            P.push('<div style="background:var(--green-lt);border:1px solid var(--green-bd);border-radius:var(--radius);');
            P.push('padding:20px 22px;color:var(--green);font-weight:700;font-size:0.95rem;">✓ No issues found on this artboard.</div>');
        } else {

        // decimal fonts
        P.push('<div class="sec"><div class="sec-hd'+(dFonts>0?' open':'')+'" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--red)"></span><span class="sec-title">Decimal Font Sizes</span></div>');
        P.push('<div class="sec-right"><span class="chip '+(dFonts>0?'chip-fonts':'chip-clean')+'">'+dFonts+'</span><span class="sec-chev">▼</span></div></div>');
        P.push('<div class="sec-body'+(dFonts>0?' open':'')+'">');
        if(dFonts===0){ P.push('<div class="ok-msg">✓ None</div>'); }
        else {
            P.push('<div class="items">');
            for(var fi=0;fi<d.fontIssues.length;fi++){
                var isf=d.fontIssues[fi];
                var sent=String(isf.sentence||""), wrd=String(isf.word||""), disp="";
                if(sent.length){
                    var ix=wrd.length?sent.toLowerCase().indexOf(wrd.toLowerCase()):-1;
                    if(ix===-1&&wrd.length) ix=sent.indexOf(wrd);
                    if(ix!==-1&&wrd.length){
                        disp=esc(sent.substring(0,ix))+'<span style="color:var(--red);font-weight:700">'+esc(sent.substring(ix,ix+wrd.length))+'</span>'+esc(sent.substring(ix+wrd.length));
                    } else disp=esc(sent);
                } else if(wrd.length) disp='<span style="color:var(--red);font-weight:700">'+esc(wrd)+'</span>';
                else disp='(unknown)';
                P.push('<div class="item red"><div class="item-title">'+(fi+1)+'. '+disp+'</div>');
                P.push('<div class="item-meta">'+esc(isf.size||'')+' pt</div></div>');
            }
            P.push('</div>');
        }
        P.push('</div></div>');

        // double spaces
        P.push('<div class="sec"><div class="sec-hd'+(dDS>0?' open':'')+'" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--blue)"></span><span class="sec-title">Double Spaces</span></div>');
        P.push('<div class="sec-right"><span class="chip '+(dDS>0?'chip-ds':'chip-clean')+'">'+dDS+'</span><span class="sec-chev">▼</span></div></div>');
        P.push('<div class="sec-body'+(dDS>0?' open':'')+'">');
        if(dDS===0){ P.push('<div class="ok-msg">✓ None</div>'); }
        else {
            P.push('<div class="items">');
            for(var di=0;di<d.dsIssues.length;di++){
                var dr=(d.dsIssues[di].text||'').length>1800?(d.dsIssues[di].text||'').substring(0,1797)+'...':(d.dsIssues[di].text||'');
                P.push('<div class="item blue"><div class="item-title">'+(di+1)+'.</div>');
                P.push('<div class="item-meta">'+renderDS(dr)+'</div></div>');
            }
            P.push('</div>');
        }
        P.push('</div></div>');

        // small fonts
        var dSF=d.smallFontIssues.length;
        P.push('<div class="sec"><div class="sec-hd'+(dSF>0?' open':'')+'" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--gold)"></span><span class="sec-title">Small Font Sizes</span></div>');
        P.push('<div class="sec-right"><span class="chip '+(dSF>0?'chip-stroke':'chip-clean')+'">'+dSF+'</span><span class="sec-chev">▼</span></div></div>');
        P.push('<div class="sec-body'+(dSF>0?' open':'')+'">');
        if(dSF===0){ P.push('<div class="ok-msg">✓ None</div>'); }
        else {
            P.push('<div class="items">');
            for(var sfi=0;sfi<d.smallFontIssues.length;sfi++){
                var sfiss=d.smallFontIssues[sfi];
                P.push('<div class="item gold">');
                P.push('<div class="item-title">'+(sfi+1)+'. '+esc(sfiss.text)+'</div>');
                P.push('<div class="item-meta">'+esc(sfiss.size)+'pt — min for '+esc(sfiss.sizeClass)+' artboard is '+sfiss.minFont+'pt</div>');
                P.push('</div>');
            }
            P.push('</div>');
        }
        P.push('</div></div>');

        // tracking / kerning
        var dTrk=(d.trackingIssues?d.trackingIssues.length:0);
        P.push('<div class="sec"><div class="sec-hd'+(dTrk>0?' open':'')+'" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--red)"></span>');
        P.push('<span class="sec-title">Tracking / Kerning</span>');
        P.push('<span style="margin-left:8px;font-size:0.72rem;color:var(--muted)">Required: '+REQUIRED_TRACKING+' for '+esc(brandName)+'</span></div>');
        P.push('<div class="sec-right"><span class="chip '+(dTrk>0?'chip-fonts':'chip-clean')+'">'+dTrk+'</span><span class="sec-chev">&#x25BC;</span></div></div>');
        P.push('<div class="sec-body'+(dTrk>0?' open':'')+'">');
        if(dTrk===0){ P.push('<div class="ok-msg">&#x2713; None</div>'); }
        else {
            P.push('<div class="items">');
            for(var tri=0;tri<d.trackingIssues.length;tri++){
                var tiss=d.trackingIssues[tri];
                P.push('<div class="item red">');
                P.push('<div class="item-title">'+(tri+1)+'. '+esc(tiss.text)+'</div>');
                P.push('<div class="item-meta">Tracking: <strong>'+tiss.tracking+'</strong> &mdash; expected <strong>'+tiss.expected+'</strong> for '+esc(tiss.brand)+'</div>');
                P.push('</div>');
            }
            P.push('</div>');
        }
        P.push('</div></div>');

        // h/v scale
        var dSc=(d.scaleIssues?d.scaleIssues.length:0);
        P.push('<div class="sec"><div class="sec-hd'+(dSc>0?' open':'')+'" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--gold)"></span>');
        P.push('<span class="sec-title">Horizontal / Vertical Scale</span>');
        P.push('<span style="margin-left:8px;font-size:0.72rem;color:var(--muted)">Must be 100%</span></div>');
        P.push('<div class="sec-right"><span class="chip '+(dSc>0?'chip-stroke':'chip-clean')+'">'+dSc+'</span><span class="sec-chev">&#x25BC;</span></div></div>');
        P.push('<div class="sec-body'+(dSc>0?' open':'')+'">');
        if(dSc===0){ P.push('<div class="ok-msg">&#x2713; None</div>'); }
        else {
            P.push('<div class="items">');
            for(var sci2=0;sci2<d.scaleIssues.length;sci2++){
                var siss=d.scaleIssues[sci2];
                P.push('<div class="item gold">');
                P.push('<div class="item-title">'+(sci2+1)+'. '+esc(siss.text)+'</div>');
                P.push('<div class="item-meta">H Scale: <strong>'+siss.hScale+'%</strong> &nbsp;|&nbsp; V Scale: <strong>'+siss.vScale+'%</strong> &mdash; both must be 100%</div>');
                P.push('</div>');
            }
            P.push('</div>');
        }
        P.push('</div></div>');

        // character rotation
        var dRot=(d.rotationIssues?d.rotationIssues.length:0);
        P.push('<div class="sec"><div class="sec-hd'+(dRot>0?' open':'')+'" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--gold)"></span>');
        P.push('<span class="sec-title">Character Rotation</span>');
        P.push('<span style="margin-left:8px;font-size:0.72rem;color:var(--muted)">Must be 0&deg;</span></div>');
        P.push('<div class="sec-right"><span class="chip '+(dRot>0?'chip-stroke':'chip-clean')+'">'+dRot+'</span><span class="sec-chev">&#x25BC;</span></div></div>');
        P.push('<div class="sec-body'+(dRot>0?' open':'')+'">');
        if(dRot===0){ P.push('<div class="ok-msg">&#x2713; None</div>'); }
        else {
            P.push('<div class="items">');
            for(var roti=0;roti<d.rotationIssues.length;roti++){
                var riss=d.rotationIssues[roti];
                P.push('<div class="item gold">');
                P.push('<div class="item-title">'+(roti+1)+'. '+esc(riss.text)+'</div>');
                P.push('<div class="item-meta">Rotation: <strong>'+riss.rotation+'&deg;</strong> &mdash; must be 0&deg;</div>');
                P.push('</div>');
            }
            P.push('</div>');
        }
        P.push('</div></div>');

        // strokes
        P.push('<div class="sec"><div class="sec-hd'+(dSt>0?' open':'')+'" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--gold)"></span><span class="sec-title">Stroke Issues</span></div>');
        P.push('<div class="sec-right"><span class="chip '+(dSt>0?'chip-stroke':'chip-clean')+'">'+dSt+'</span><span class="sec-chev">▼</span></div></div>');
        P.push('<div class="sec-body'+(dSt>0?' open':'')+'">');
        if(dSt===0){ P.push('<div class="ok-msg">✓ None</div>'); }
        else {
            P.push('<div class="items">');
            for(var sti=0;sti<d.strokeIssues.length;sti++){
                P.push('<div class="item gold"><div class="item-title">'+(sti+1)+'. '+esc(d.strokeIssues[sti].type)+'</div>');
                P.push('<div class="item-meta">'+esc(d.strokeIssues[sti].width)+' pt — must be whole, 0.5 or 0.75</div></div>');
            }
            P.push('</div>');
        }
        P.push('</div></div>');

        // outside artboard
        P.push('<div class="sec"><div class="sec-hd'+(dOut>0?' open':'')+'" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--purple)"></span><span class="sec-title">Outside Artboard</span></div>');
        P.push('<div class="sec-right"><span class="chip '+(dOut>0?'chip-out':'chip-clean')+'">'+dOut+'</span><span class="sec-chev">▼</span></div></div>');
        P.push('<div class="sec-body'+(dOut>0?' open':'')+'">');
        if(dOut===0){ P.push('<div class="ok-msg">✓ None</div>'); }
        else {
            P.push('<div style="display:flex;flex-direction:column;gap:10px;margin-top:4px;">');
            for(var oi=0;oi<d.outsideIssues.length;oi++){
                var oiss = d.outsideIssues[oi];
                P.push('<div class="item purple">');
                P.push('<div class="item-title">'+(oi+1)+'. '+esc(oiss.type)+'</div>');
                if (oiss.shot) {
                    P.push('<div style="margin-top:8px;border-radius:6px;overflow:hidden;border:1px solid var(--purple-bd);background:#fff;">');
                    P.push('<img src="data:image/png;base64,'+oiss.shot+'" style="width:100%;height:auto;display:block;max-height:300px;object-fit:contain;" alt="Object preview"/>');
                    P.push('</div>');
                } else {
                    P.push('<div class="item-meta" style="margin-top:4px;font-style:italic;">Preview unavailable</div>');
                }
                P.push('</div>');
            }
            P.push('</div>');
        }
        P.push('</div></div>');

        // off-brand colors
        P.push('<div class="sec"><div class="sec-hd'+(dCol>0?' open':'')+'" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--orange)"></span><span class="sec-title">Off-Brand Fill Colors</span></div>');
        P.push('<div class="sec-right"><span class="chip '+(dCol>0?'chip-color':'chip-clean')+'">'+dCol+'</span><span class="sec-chev">▼</span></div></div>');
        P.push('<div class="sec-body'+(dCol>0?' open':'')+'">');
        if(dCol===0){ P.push('<div class="ok-msg">✓ None</div>'); }
        else {
            P.push('<div class="items">');
            for(var ci=0;ci<d.colorIssues.length;ci++){
                var col=d.colorIssues[ci];
                P.push('<div class="item orange"><div class="item-title"><span class="sw-dot" style="background:'+col.hex+'"></span>'+(ci+1)+'. '+esc(col.type)+'</div>');
                P.push('<div class="item-meta">RGB '+col.rgb[0]+' '+col.rgb[1]+' '+col.rgb[2]+'&ensp;'+col.hex+'</div></div>');
            }
            P.push('</div>');
        }
        P.push('</div></div>');

        // unapproved fonts
        P.push('<div class="sec"><div class="sec-hd'+(dBF>0?' open':'')+'" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--purple)"></span><span class="sec-title">Unapproved Fonts</span></div>');
        P.push('<div class="sec-right"><span class="chip '+(dBF>0?'chip-bfont':'chip-clean')+'">'+dBF+'</span><span class="sec-chev">▼</span></div></div>');
        P.push('<div class="sec-body'+(dBF>0?' open':'')+'">');
        if(dBF===0){ P.push('<div class="ok-msg">✓ None</div>'); }
        else {
            P.push('<div class="items">');
            for(var bfi=0;bfi<d.fontNameIssues.length;bfi++){
                P.push('<div class="item purple"><div class="item-title">'+(bfi+1)+'. '+esc(d.fontNameIssues[bfi].font)+'</div>');
                P.push('<div class="item-meta">&ldquo;'+esc(d.fontNameIssues[bfi].sample)+'&rdquo;</div></div>');
            }
            P.push('</div>');
        }
        P.push('</div></div>');

        } // end has issues
        P.push('</div>'); // end page
    }

    // outside-all page
    if (outsideAll.hasIssues) {
        var oT=outsideAll.outsideIssues.length;
        P.push('<div class="page" id="p-outside">');
        P.push('<div class="pg-title"><h2>Outside All Artboards</h2><p>'+oT+' item'+(oT!==1?'s':'')+'</p></div>');
        P.push('<div class="sec"><div class="sec-hd open" onclick="tog(this)">');
        P.push('<div class="sec-left"><span class="sec-dot" style="background:var(--purple)"></span><span class="sec-title">Items Outside</span></div>');
        P.push('<div class="sec-right"><span class="chip chip-out">'+oT+'</span><span class="sec-chev">▼</span></div></div>');
        P.push('<div class="sec-body open"><div style="display:flex;flex-direction:column;gap:10px;margin-top:4px;">');
        for(var oii=0;oii<outsideAll.outsideIssues.length;oii++){
            var oaiss = outsideAll.outsideIssues[oii];
            P.push('<div class="item purple">');
            P.push('<div class="item-title">'+(oii+1)+'. '+esc(oaiss.type)+'</div>');
            if (oaiss.shot) {
                P.push('<div style="margin-top:8px;border-radius:6px;overflow:hidden;border:1px solid var(--purple-bd);background:#fff;">');
                P.push('<img src="data:image/png;base64,'+oaiss.shot+'" style="width:100%;height:auto;display:block;max-height:300px;object-fit:contain;" alt="Object preview"/>');
                P.push('</div>');
            } else {
                P.push('<div class="item-meta" style="margin-top:4px;font-style:italic;">Preview unavailable</div>');
            }
            P.push('</div>');
        }
        P.push('</div></div></div>');
        P.push('</div>');
    }

    P.push('</main></div>'); // end layout

    // footer
    P.push('<div class="footer">Brix QC Script &nbsp;·&nbsp; Brand: '+esc(brandName)+'</div>');

    // ========================================================
    //  JAVASCRIPT
    // ========================================================
    P.push('<script>');

    // navigation
    P.push('function nav(id,btn){');
    P.push('  document.querySelectorAll(".page").forEach(function(p){p.classList.remove("on");});');
    P.push('  var pg=document.getElementById("p-"+id);');
    P.push('  if(pg){pg.classList.add("on");window.scrollTo({top:0,behavior:"smooth"});}');
    P.push('  document.querySelectorAll(".sb-btn").forEach(function(b){b.classList.remove("active");});');
    P.push('  if(btn)btn.classList.add("active");');
    P.push('}');

    // collapse toggle
    P.push('function tog(hd){');
    P.push('  var body=hd.nextElementSibling;');
    P.push('  if(!body)return;');
    P.push('  var open=body.classList.toggle("open");');
    P.push('  hd.classList.toggle("open",open);');
    P.push('}');

    // init chevron states
    P.push('document.querySelectorAll(".sec-hd:not(.open) .sec-chev").forEach(function(c){c.style.transform="rotate(-90deg)";});');
    // but chevrons in .open headers should point down (default)

    P.push('<\/script>');

    // ── CONFETTI (only injected when zero issues) ──
    if (isPass) {
        P.push('<canvas id="confetti-canvas" style="position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:9999;"></canvas>');
        P.push('<script>');
        P.push('(function(){');
        P.push('  var C=document.getElementById("confetti-canvas");');
        P.push('  var ctx=C.getContext("2d");');
        P.push('  var W,H,parts=[];');
        P.push('  var COLORS=["#6C5CE7","#00b894","#e03e3e","#2d8cf0","#d4890a","#9b51e0","#f368e0","#00cec9","#fdcb6e","#fd79a8"];');
        P.push('  var SHAPES=["rect","circle","ribbon"];');
        P.push('  function resize(){W=C.width=window.innerWidth;H=C.height=window.innerHeight;}');
        P.push('  resize();');
        P.push('  window.addEventListener("resize",resize);');
        // spawn a wave of particles
        P.push('  function spawn(n){');
        P.push('    for(var i=0;i<n;i++){');
        P.push('      parts.push({');
        P.push('        x: Math.random()*W,');
        P.push('        y: -20 - Math.random()*H*0.5,');
        P.push('        w: 7+Math.random()*9,');
        P.push('        h: 4+Math.random()*6,');
        P.push('        r: Math.random()*Math.PI*2,');
        P.push('        dr: (Math.random()-0.5)*0.18,');
        P.push('        dx: (Math.random()-0.5)*2.5,');
        P.push('        dy: 2.5+Math.random()*3.5,');
        P.push('        color: COLORS[Math.floor(Math.random()*COLORS.length)],');
        P.push('        shape: SHAPES[Math.floor(Math.random()*SHAPES.length)],');
        P.push('        opacity: 0.85+Math.random()*0.15,');
        P.push('        wobble: Math.random()*Math.PI*2,');
        P.push('        wobbleSpeed: 0.05+Math.random()*0.08');
        P.push('      });');
        P.push('    }');
        P.push('  }');
        // draw one particle
        P.push('  function drawPart(p){');
        P.push('    ctx.save();');
        P.push('    ctx.globalAlpha=p.opacity;');
        P.push('    ctx.fillStyle=p.color;');
        P.push('    ctx.translate(p.x,p.y);');
        P.push('    ctx.rotate(p.r);');
        P.push('    if(p.shape==="circle"){');
        P.push('      ctx.beginPath();ctx.arc(0,0,p.w/2,0,Math.PI*2);ctx.fill();');
        P.push('    } else if(p.shape==="ribbon"){');
        P.push('      ctx.beginPath();ctx.moveTo(-p.w/2,0);ctx.lineTo(0,-p.h/2);ctx.lineTo(p.w/2,0);ctx.lineTo(0,p.h/2);ctx.closePath();ctx.fill();');
        P.push('    } else {');
        P.push('      ctx.fillRect(-p.w/2,-p.h/2,p.w,p.h);');
        P.push('    }');
        P.push('    ctx.restore();');
        P.push('  }');
        // main loop
        P.push('  function loop(){');
        P.push('    ctx.clearRect(0,0,W,H);');
        P.push('    for(var i=parts.length-1;i>=0;i--){');
        P.push('      var p=parts[i];');
        P.push('      p.wobble+=p.wobbleSpeed;');
        P.push('      p.x+=p.dx+Math.sin(p.wobble)*1.2;');
        P.push('      p.y+=p.dy;');
        P.push('      p.r+=p.dr;');
        P.push('      p.opacity-=0.003;');
        P.push('      drawPart(p);');
        P.push('      if(p.y>H+20||p.opacity<=0) parts.splice(i,1);');
        P.push('    }');
        P.push('    requestAnimationFrame(loop);');
        P.push('  }');
        // spawn waves continuously for loop effect
        P.push('  function wave(){spawn(60);setTimeout(wave,1200);}');
        P.push('  spawn(120);');   // big initial burst
        P.push('  wave();');
        P.push('  loop();');
        P.push('})();');
        P.push('<\/script>');
    }

    P.push('</body></html>');

    // =========================================================
    //  SAVE REPORT
    // =========================================================
    var html = P.join("");
    var fname = docName + "_QC_Report.html";
    var fout  = new File(saveFolder + "/" + fname);
    fout.encoding = "UTF-8";
    if (fout.open("w")) {
        fout.write(html);
        fout.close();
        try { if (fout.exists) fout.execute(); } catch(e){}
        alert("QC Report saved:\n" + fout.fsName);
    } else {
        alert("Could not write report file.");
    }

} // end brandChoice block

main();

// =========================================================
//  GLOBAL HELPERS (outside IIFE — Illustrator hoisting)
// =========================================================
function validStroke(w) {
    var r = Math.round(w*100)/100 % 1;
    r = Math.round(r*100)/100;
    return (r===0 || r===0.25 || r===0.5 || r===0.75);
}
function badSwatchName(sw) {
    try {
        var n = sw.name.toLowerCase();
        if(n==="[none]"||n==="[registration]"||n==="[black]"||n==="[paper]"||n==="[white]") return false;
        return !!(n.match(/^new swatch/i)||n.match(/^swatch/i)||
                  n.match(/^c=\d+\s*m=\d+\s*y=\d+\s*k=\d+/i)||
                  n.match(/^r=\d+\s*g=\d+\s*b=\d+/i)||
                  n.match(/^gray=/i)||n.match(/^#/));
    } catch(e){ return false; }
}