/*
v11 Updates:
- REMOVED all inline comments from the worker payload to prevent BridgeTalk syntax errors.
- IMPROVED extension removal to strictly strip '.ai' before sanitization.
- RETAINED all security and safety checks.
*/

#targetengine "com.syed.exportpng.secure"

(function () {

    if ($.global.syedScriptIsRunning) {
        return;
    }
    $.global.syedScriptIsRunning = true;

    try {
        var runExportPayload = function() {
            try {
                if (app.documents.length === 0) {
                    alert("No document open.");
                    return;
                }

                var doc = app.activeDocument;
                doc.activate();

                if (!confirm("Deleting empty Layers and Artboards. Confirm?")) {
                    return;
                }

                function safeTrim(s) {
                    try { return String(s).replace(/^\s+|\s+$/g, ""); }
                    catch (e) { return String(s); }
                }

                function sanitizeFilename(name) {
                    return String(name).replace(/[^a-zA-Z0-9 _-]/g, "-");
                }

                var scalePct = Math.round((300 / 72) * 100);
                var exportFolder;
                try {
                    exportFolder = doc.path;
                } catch(e) {
                    alert("Please save the document before exporting.");
                    return;
                }

                var originalName = doc.name;
                var nameWithoutExt = originalName;
                if (originalName.lastIndexOf(".") > 0) {
                    nameWithoutExt = originalName.substring(0, originalName.lastIndexOf("."));
                }
                
                var baseName = sanitizeFilename(safeTrim(nameWithoutExt));
                if (!baseName) baseName = "Untitled-Export";

                function deleteEmptyLayers(container) {
                    for (var i = container.layers.length - 1; i >= 0; i--) {
                        var layer = container.layers[i];
                        try { deleteEmptyLayers(layer); } catch(e) {}
                        try {
                            var hasItems = (layer.pageItems && layer.pageItems.length > 0);
                            var hasSublayers = (layer.layers && layer.layers.length > 0);
                            if (!hasItems && !hasSublayers && !layer.locked && layer.visible) {
                                layer.remove();
                            }
                        } catch (e) {}
                    }
                }
                try { deleteEmptyLayers(doc); } catch(e) {}

                function isArtboardEmpty(ab) {
                    var abRect = ab.artboardRect;
                    var items = doc.pageItems;
                    for (var i = 0; i < items.length; i++) {
                        try {
                            var vb = items[i].visibleBounds;
                            if (vb[2] > abRect[0] && vb[0] < abRect[2] &&
                                vb[1] > abRect[3] && vb[3] < abRect[1]) {
                                    return false;
                            }
                        } catch (e) {}
                    }
                    return true;
                }

                for (var ai = doc.artboards.length - 1; ai >= 0; ai--) {
                    try {
                        var ab = doc.artboards[ai];
                        if (isArtboardEmpty(ab)) doc.artboards.remove(ai);
                    } catch (e) {}
                }

                var abCount = doc.artboards.length;
                var errors = [];
                
                for (var ai = 0; ai < abCount; ai++) {
                    try {
                        doc.activate();
                        var ab = doc.artboards[ai];
                        doc.artboards.setActiveArtboardIndex(ai);

                        var desiredName = baseName;
                        if (abCount > 1) {
                            var abName = sanitizeFilename(safeTrim(ab.name));
                            var isDefaultName = (abName.toLowerCase().indexOf("artboard") === 0);
                                                 
                            if (abName && !isDefaultName) {
                                desiredName += " " + abName;
                            }
                        }
                        desiredName += ".png";

                        var outFile = new File(exportFolder.fsName + "/" + desiredName);
                        
                        var opts = new ExportOptionsPNG24();
                        opts.artBoardClipping = true;
                        opts.horizontalScale = scalePct;
                        opts.verticalScale = scalePct;
                        opts.transparency = true;
                        opts.antiAliasing = true;

                        if (outFile.exists) try { outFile.remove(); } catch(e) {}
                        
                        doc.exportFile(outFile, ExportType.PNG24, opts);

                        var variants = [
                            baseName.replace(/ /g, "-"),
                            baseName.replace(/ /g, "_"),
                            baseName.replace(/ /g, "")
                        ];
                        
                        if (abCount > 1) {
                            var safeAbName = sanitizeFilename(safeTrim(ab.name));
                            for (var v = 0; v < variants.length; v++) {
                                var candidates = [
                                    variants[v] + " " + safeAbName + ".png",
                                    variants[v] + "-" + safeAbName + ".png",
                                    variants[v] + "_" + safeAbName + ".png",
                                    variants[v] + safeAbName + ".png"
                                ];
                                for (var c=0; c<candidates.length; c++) {
                                    var alt = new File(exportFolder.fsName + "/" + candidates[c]);
                                    if (alt.exists && alt.fsName !== outFile.fsName) {
                                        try { alt.rename(desiredName); } catch(e) {}
                                    }
                                }
                            }
                        }

                    } catch (innerErr) {
                        errors.push("Artboard " + (ai+1) + " failed: " + innerErr);
                    }
                }

                try { doc.save(); } catch (e) {}

                if (errors.length > 0) {
                    alert("Export completed with errors:\n" + errors.join("\n"));
                } else {
                    alert("PNG's Exported");
                }

            } catch(err) {
                alert("Main Script Error: " + err);
            }
        };

        var bt = new BridgeTalk();
        bt.target = "illustrator";
        bt.body = "(" + runExportPayload.toString() + ")();";
        bt.onResult = function(res) { $.global.syedScriptIsRunning = false; };
        bt.onError = function(err) { 
            $.global.syedScriptIsRunning = false; 
            alert("BridgeTalk Error: " + err.body);
        };
        bt.send();

    } catch (e) {
        alert("Launch Error: " + e);
        $.global.syedScriptIsRunning = false;
    }

})();