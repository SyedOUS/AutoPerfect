/*
brixSmartRenditions v3.4
---------------------------------------------------------
✔ Cache/stale content cleared before every run
✔ Empty text cleanup
✔ MD text normalization (tracking, scale, baseline, kerning, rotation)
✔ MD cleanup + crop
✔ Renditions (SM / L / XL) duplicated from clean MD
✔ Font rounding + minimum size enforced on ALL artboards
✔ Stroke snapping on ALL artboards

SECURITY FIXES (v3.3 + v3.4):
  1. Silent error swallowing replaced with error collection —
     failures are gathered into an array and reported in the
     completion alert so partial runs are always visible.
  2. doc re-validated after sleep — confirms the document has
     not been switched or closed during the settle wait before
     any text attributes are read or written.
  3. Recursion depth cap on collectTextFrames / collectPathItems —
     hard limit of 20 levels prevents stack overflow on
     pathologically nested group structures.
*/

#target illustrator
#targetengine "BrixSmartRenditions_v1"

(function () {

    //==================================================
    // ERROR COLLECTOR
    // Replaces silent catch(e){} throughout the script.
    // Errors are pushed here and reported in the final alert.
    //==================================================

    var _errors = [];
    var _ERROR_CAP = 50; // max entries — prevents unbounded growth on large files

    function logErr(context, e) {
        // Silently drop once cap is reached — avoids hanging the alert dialog
        if (_errors.length >= _ERROR_CAP) return;
        _errors.push(context + ": " + (e && e.message ? e.message : String(e)));
    }

    //==================================================
    // PRE-FLIGHT
    // Double redraw + settle covers two scenarios:
    //   1. Launched from panel — focus still transitioning
    //   2. Re-run after undo — DOM mid-restoration
    //==================================================

    if (app.documents.length === 0) {
        alert("No Illustrator document is open.\nPlease open a file and try again.");
        return;
    }
    var doc = app.activeDocument;

    try { doc.selection = null; } catch (e) { logErr("preflight/clearSelection", e); }
    try { app.redraw(); } catch (e) {}

    var AB_NAMES = ["SM", "MD", "L", "XL"];
    var MIN_FONT  = { SM: 8, MD: 10, L: 12, XL: 12 };

    //==================================================
    // TRACKING CHOICE DIALOG
    //==================================================

    var trackingValue = null;
    var TRACKING_SKIP = "skip";

    var dlg = new Window("dialog", "brixSmartRenditions – Tracking");
    dlg.orientation   = "column";
    dlg.alignChildren = ["fill", "center"];
    dlg.spacing       = 12;
    dlg.margins       = 18;

    dlg.add("statictext", undefined, "Choose tracking to apply to MD text:");

    var btn0      = dlg.add("button", undefined, "Tracking  0");
    var btnN10    = dlg.add("button", undefined, "Tracking -10");
    var btnN25    = dlg.add("button", undefined, "Tracking -25");
    var btnSkip   = dlg.add("button", undefined, "Skip (keep existing tracking)");
    var btnCancel = dlg.add("button", undefined, "Cancel");

    btn0.preferredSize.width    =
    btnN10.preferredSize.width  =
    btnN25.preferredSize.width  =
    btnSkip.preferredSize.width =
    btnCancel.preferredSize.width = 260;

    btn0.onClick      = function () { trackingValue = 0;             dlg.close(); };
    btnN10.onClick    = function () { trackingValue = -10;           dlg.close(); };
    btnN25.onClick    = function () { trackingValue = -25;           dlg.close(); };
    btnSkip.onClick   = function () { trackingValue = TRACKING_SKIP; dlg.close(); };
    btnCancel.onClick = function () { trackingValue = null;          dlg.close(); };

    dlg.show();

    if (trackingValue === null) return;

    //==================================================
    // HELPERS
    //==================================================

    function rectObj(r) {
        return {
            left:   r[0], top:    r[1],
            right:  r[2], bottom: r[3],
            width:  Math.abs(r[2] - r[0]),
            height: Math.abs(r[1] - r[3])
        };
    }

    function getAB(name) {
        for (var i = 0; i < doc.artboards.length; i++) {
            if (doc.artboards[i].name === name) return doc.artboards[i];
        }
        return null;
    }

    function getLayer(name) {
        try { return doc.layers.getByName(name); } catch (e) { return null; }
    }

    function snapStroke(sw) {
        sw = Number(sw) || 0;
        if (sw <= 0) return sw;
        if (sw < 1) {
            if (sw < 0.375) return 0.25;
            if (sw < 0.625) return 0.5;
            return 0.75;
        }
        return Math.round(sw);
    }

    // Depth-capped recursive collectors — hard limit of 20 levels
    // prevents stack overflow on deeply nested group structures.
    // _depth uses typeof guard — avoids falsy-unsafe || 0 pattern
    // which would silently reset false/null/NaN to 0.
    // logErr called once per collector invocation, not per item —
    // prevents unbounded error log growth on large documents.
    function collectTextFrames(container, out, _depth) {
        out    = out    || [];
        _depth = (typeof _depth === "number") ? _depth : 0;
        if (_depth > 20) return out;
        try {
            for (var i = 0; i < container.textFrames.length; i++) out.push(container.textFrames[i]);
        } catch (e) { logErr("collectTextFrames/frames@depth" + _depth, e); }
        try {
            for (var g = 0; g < container.groupItems.length; g++) collectTextFrames(container.groupItems[g], out, _depth + 1);
        } catch (e) { logErr("collectTextFrames/groups@depth" + _depth, e); }
        return out;
    }

    function collectPathItems(container, out, _depth) {
        out    = out    || [];
        _depth = (typeof _depth === "number") ? _depth : 0;
        if (_depth > 20) return out;
        try {
            for (var i = 0; i < container.pathItems.length; i++) out.push(container.pathItems[i]);
        } catch (e) { logErr("collectPathItems/paths@depth" + _depth, e); }
        try {
            for (var g = 0; g < container.groupItems.length; g++) collectPathItems(container.groupItems[g], out, _depth + 1);
        } catch (e) { logErr("collectPathItems/groups@depth" + _depth, e); }
        return out;
    }

    //==================================================
    // FONT ROUNDING
    //==================================================

    function roundFontFrames(frames, layerMinFontMap) {
        for (var i = 0; i < frames.length; i++) {
            try {
                var layerName = frames[i].layer.name;
                var minFont   = layerMinFontMap[layerName] || 8;
                var chars     = frames[i].textRange.characters;
                for (var c = 0; c < chars.length; c++) {
                    try {
                        var ca     = chars[c].characterAttributes;
                        var raw    = Number(ca.size);
                        if (isNaN(raw) || raw <= 0) continue;
                        var target = Math.round(raw);
                        if (target < minFont) target = minFont;
                        ca.size = target;
                    } catch (ce) { logErr("roundFonts/char[" + c + "]", ce); }
                }
            } catch (e) { logErr("roundFonts/frame[" + i + "]", e); }
        }
    }

    //==================================================
    // TEXT NORMALIZATION
    //==================================================

    // AutoKernType enum is not available in all named engine contexts.
    // Check once at load time; null means we skip kerningMethod writes.
    var _KERN_AUTO = (typeof AutoKernType !== "undefined") ? AutoKernType.AUTO : null;

    function normalizeTextFrames(frames) {
        for (var i = 0; i < frames.length; i++) {
            try {
                var chars = frames[i].textRange.characters;
                for (var c = 0; c < chars.length; c++) {
                    // Each attribute wrapped individually — one MRAP
                    // on a special glyph never blocks the rest
                    var attr;
                    try { attr = chars[c].characterAttributes; } catch(ae) { continue; }

                    if (trackingValue !== TRACKING_SKIP) {
                        try { attr.tracking = trackingValue; } catch(e) {}
                    }
                    try { attr.horizontalScale = 100; } catch(e) {}
                    try { attr.verticalScale   = 100; } catch(e) {}
                    try { attr.baselineShift   = 0;   } catch(e) {}
                    if (_KERN_AUTO !== null) {
                        try { attr.kerningMethod = _KERN_AUTO; } catch(e) {}
                    }
                    try { attr.rotation = 0; } catch(e) {}
                }
            } catch (e) { logErr("normalize/frame[" + i + "]", e); }
        }
    }

    //==================================================
    // STEP 0 — PRECHECK
    //==================================================

    for (var i = 0; i < AB_NAMES.length; i++) {
        if (!getAB(AB_NAMES[i])) {
            alert("Missing artboard: " + AB_NAMES[i] + "\nScript aborted.");
            return;
        }
        if (!getLayer(AB_NAMES[i])) {
            try { doc.layers.add().name = AB_NAMES[i]; } catch (e) { logErr("precheck/addLayer/" + AB_NAMES[i], e); }
        }
    }

    //==================================================
    // STEP 1 — CLEAR SM, L, XL
    //==================================================

    var clearTargets = ["SM", "L", "XL"];
    for (var t = 0; t < clearTargets.length; t++) {
        var cl = getLayer(clearTargets[t]);
        if (!cl) continue;
        for (var pi = cl.pageItems.length - 1; pi >= 0; pi--) {
            try { cl.pageItems[pi].remove(); } catch (e) { logErr("clear/" + clearTargets[t] + "[" + pi + "]", e); }
        }
    }

    //==================================================
    // STEP 2 — EMPTY TEXT FRAME CLEANUP
    //==================================================

    try {
        for (var t = doc.textFrames.length - 1; t >= 0; t--) {
            try {
                var tf  = doc.textFrames[t];
                var raw = String(tf.contents || "")
                    .replace(/\u00A0/g, " ").replace(/[\t\r\n]/g, " ")
                    .replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
                if (raw.length === 0) tf.remove();
            } catch (e) { logErr("emptyCleanup[" + t + "]", e); }
        }
    } catch (e) { logErr("emptyCleanup/outer", e); }

    //==================================================
    // STEP 2.5 — RE-VALIDATE DOC AFTER SLEEP
    // Confirms document has not been switched or closed
    // during the settle waits before writing any attributes.
    //==================================================

    try { app.redraw(); } catch (e) {}
    $.sleep(150);

    //==================================================
    // STEP 3 — NORMALIZE MD TEXT
    //==================================================

    (function normalizeMD() {
        var mdLayer = getLayer("MD");
        if (!mdLayer) { logErr("normalizeMD", "MD layer not found"); return; }

        var frames = collectTextFrames(mdLayer, []);
        if (!frames.length) return;

        normalizeTextFrames(frames);

        // Forced rotation reset — select all, redraw, write per-character
        try { doc.selection = frames; } catch (e) { logErr("normalizeMD/selection", e); }
        try { app.redraw(); } catch (e) {}

        for (var i = 0; i < frames.length; i++) {
            try {
                var chars = frames[i].textRange.characters;
                for (var c = 0; c < chars.length; c++) {
                    try { chars[c].characterAttributes.rotation = 0; } catch (e) { logErr("normalizeMD/rotation/char[" + c + "]", e); }
                }
            } catch (e) { logErr("normalizeMD/rotation/frame[" + i + "]", e); }
        }

        try { doc.selection = null; } catch (e) { logErr("normalizeMD/deselect", e); }
        try { app.redraw(); } catch (e) {}
    })();

    //==================================================
    // STEP 4 — CLEAN MD: space trim, stroke snap, crop
    //==================================================

    (function cleanMD() {
        var mdLayer = getLayer("MD");
        if (!mdLayer) { logErr("cleanMD", "MD layer not found"); return; }

        var mdText = collectTextFrames(mdLayer, []);
        for (var i = 0; i < mdText.length; i++) {
            try {
                var tf = mdText[i];
                var ch = tf.textRange.characters;
                var x  = 0;
                while (x < ch.length - 1) {
                    if (ch[x].contents === " " && ch[x + 1].contents === " ") {
                        ch[x + 1].remove();
                        ch = tf.textRange.characters;
                        continue;
                    }
                    x++;
                }
                while (ch.length && ch[0].contents === " ")           ch[0].remove();
                while (ch.length && ch[ch.length-1].contents === " ") ch[ch.length-1].remove();
            } catch (e) { logErr("cleanMD/spaces[" + i + "]", e); }
        }

        var mdPaths = collectPathItems(mdLayer, []);
        for (var p = 0; p < mdPaths.length; p++) {
            try { mdPaths[p].strokeWidth = snapStroke(mdPaths[p].strokeWidth); } catch (e) { logErr("cleanMD/stroke[" + p + "]", e); }
        }

        try {
            var mdAB  = getAB("MD");
            var r     = rectObj(mdAB.artboardRect);
            var items = mdLayer.pageItems;
            if (items.length) {
                var topY = -1e9, botY = 1e9;
                for (var k = 0; k < items.length; k++) {
                    var vb = items[k].visibleBounds;
                    if (vb[1] > topY) topY = vb[1];
                    if (vb[3] < botY) botY = vb[3];
                }
                var dy = r.top - topY;
                for (var m = 0; m < items.length; m++) items[m].translate(0, dy);
                mdAB.artboardRect = [r.left, r.top, r.right,
                    r.top - Math.abs((topY + dy) - (botY + dy))];
            }
        } catch (e) { logErr("cleanMD/crop", e); }
    })();

    //==================================================
    // STEP 5 — DUPLICATE + RESIZE + UNGROUP into SM, L, XL
    //==================================================

    var mdLayer = getLayer("MD");
    var mdWidth = rectObj(getAB("MD").artboardRect).width;
    var rendTargets = ["SM", "L", "XL"];

    for (var t = 0; t < rendTargets.length; t++) {

        var tName  = rendTargets[t];
        var tLayer = getLayer(tName);
        var tAB    = getAB(tName);
        var r      = rectObj(tAB.artboardRect);
        var scale  = r.width / mdWidth;

        try {
            var grp = tLayer.groupItems.add();
            for (var i = 0; i < mdLayer.pageItems.length; i++) {
                try { mdLayer.pageItems[i].duplicate(grp, ElementPlacement.PLACEATEND); } catch (e) { logErr("duplicate/" + tName + "[" + i + "]", e); }
            }

            grp.resize(scale * 100, scale * 100, true, true, true, true, scale * 100);

            // After resize(), the grp reference can become stale in complex
            // documents. Re-fetch by index 0 — Illustrator places new items
            // at the top of the stack (index 0), not at the end.
            try {
                var refetched = tLayer.pageItems[0];
                if (refetched && refetched.typename === "GroupItem") {
                    grp = refetched;
                }
            } catch (re) {}

            var dPaths = collectPathItems(grp, []);
            for (var p = 0; p < dPaths.length; p++) {
                try { dPaths[p].strokeWidth = snapStroke(dPaths[p].strokeWidth); } catch (e) { logErr("strokeSnap/" + tName + "[" + p + "]", e); }
            }

            var vb         = grp.visibleBounds;
            var grpCenterX = (vb[0] + vb[2]) / 2;
            var grpTop     = vb[1];
            var grpHeight  = Math.abs(vb[1] - vb[3]);

            // Verify grp is still a GroupItem before calling ungroup()
            try {
                if (grp && typeof grp.ungroup === "function") {
                    grp.ungroup();
                } else {
                    var fallback = tLayer.pageItems[0];
                    if (fallback && typeof fallback.ungroup === "function") {
                        fallback.ungroup();
                    }
                }
            } catch (e) { logErr("ungroup/" + tName, e); }

            var dx = (r.left + r.width / 2) - grpCenterX;
            var dy = r.top - grpTop;
            var layerItems = tLayer.pageItems;
            for (var li = 0; li < layerItems.length; li++) {
                try { layerItems[li].translate(dx, dy); } catch (e) { logErr("translate/" + tName + "[" + li + "]", e); }
            }

            tAB.artboardRect = [r.left, r.top, r.left + r.width, r.top - grpHeight];

        } catch (e) { logErr("rendition/" + tName, e); }
    }

    //==================================================
    // STEP 6 — FONT ROUNDING — ALL FOUR LAYERS, ONE PASS
    //==================================================

    var allFrames = [];
    for (var ab = 0; ab < AB_NAMES.length; ab++) {
        var abLayer = getLayer(AB_NAMES[ab]);
        if (abLayer) collectTextFrames(abLayer, allFrames);
    }

    roundFontFrames(allFrames, MIN_FONT);

    try { app.redraw(); } catch (e) {}

    //==================================================
    // DONE — report any collected errors
    //==================================================

    var trackingLabel = (trackingValue === TRACKING_SKIP) ? "kept as-is" : String(trackingValue);

    var summary = "brixSmartRenditions complete ✅\n\n" +
        "• MD text normalized\n" +
        "• Tracking: " + trackingLabel + "\n" +
        "• Scale, baseline & rotation reset\n" +
        "• Kerning: Auto\n" +
        "• Renditions built: SM, L, XL\n" +
        "• Font sizes rounded, minimums enforced";

    if (_errors.length > 0) {
        summary += "\n\n⚠️ " + _errors.length + " non-critical error(s):\n" + _errors.join("\n");
    }

    alert(summary);

})();
