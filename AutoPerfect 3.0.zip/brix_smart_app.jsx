// Brix Smart App Panel
// Version 2.9.0
#target illustrator
#targetengine "MagicFix_ButtonAbbrev_v252"

// --- START JSON POLYFILL ---
if (typeof JSON !== "object") { var JSON = {}; }
(function () {
    "use strict";
    if (typeof JSON.stringify !== "function") {
        JSON.stringify = function (value) {
            var type = typeof value;
            if (type === "string") {
                return '"' + value.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r') + '"';
            }
            if (type === "number" || type === "boolean") { return String(value); }
            return "null";
        };
    }
})();
// --- END JSON POLYFILL ---

(function () {
    "use strict";

    /* =========================================================
       CONFIG
    ========================================================= */
    if (!$.fileName || $.fileName.length === 0) {
        alert("Cannot resolve panel path. Please launch by running the .jsx file directly.");
        return;
    }
    var _scriptDir = File($.fileName).parent.fsName + "/";

    var CONFIG = {
        scriptsFolderPath: _scriptDir,
        panel:  { title: " " },
        logo:   { width: 182, height: 55, file: "icons/brix_logo.png" },
        button: { size: { w: 48, h: 48 }, gapX: 32 },
        colors: {
            darkBg:    [0.176, 0.122, 0.354, 1],  // original purple
            white:     [1,     1,     1,     1],
            dimWhite:  [0.3,   0.3,   0.3,   1],
            separator: [1,     1,     1,     1]
        }
    };

    var ITEMS = [
        { label: "Magic Fix",        line1: "Magic",  line2: "Fix",        file: "brixMagicCleanup.jsx",    abbrev: "FIX"   },
        { label: "Quick Renditions", line1: "Quick",  line2: "Renditions", file: "brixSmartRenditions.jsx", abbrev: "QR"    },
        { label: "QC Unlocked",      line1: "QC",     line2: "Unlocked",   file: "brix QC Unlocked.jsx",    abbrev: "QC"    },
        { label: "Export PNGs",      line1: "Export", line2: "PNGs",       file: "exportPng.jsx",           abbrev: "PNG's" },
        { label: "Guide",      line1: "Guide", line2: "Book",       file: "openHomepage.jsx",           abbrev: "How" }
    ];

    /* =========================================================
       SECURITY
    ========================================================= */
    function validateConfiguration() {
        if (!ITEMS || ITEMS.length === 0) {
            alert("Critical Error: Scripts registry is empty.");
            return false;
        }
        for (var i = 0; i < ITEMS.length; i++) {
            if (!ITEMS[i].file || !ITEMS[i].abbrev) {
                alert("Configuration Error: Item #" + (i + 1) + " is invalid.");
                return false;
            }
        }
        return true;
    }

    function isAllowedScript(f) {
        for (var i = 0; i < ITEMS.length; i++) {
            if (ITEMS[i].file === f) return true;
        }
        return false;
    }

    var _dirNorm = _scriptDir.replace(/\\/g, "/").replace(/\/+$/, "").toLowerCase();

    function isWithinScriptsFolder(fileObj) {
        var n = fileObj.fsName.replace(/\\/g, "/").replace(/\/+$/, "").toLowerCase();
        return (n + "/").indexOf(_dirNorm + "/") === 0;
    }

    /* =========================================================
       EXECUTION
    ========================================================= */
    function launchViaBT(fileObj) {
        try {
            var bt     = new BridgeTalk();
            bt.target  = "illustrator";
            var ep     = fileObj.fsName.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
            bt.body    = 'try { $.evalFile(File("' + ep + '")); } catch(e) { alert("BT Error: " + e); }';
            bt.onError = function (msg) { alert("BridgeTalk error: " + msg.body); };
            bt.send(30);
        } catch (e) { alert("BridgeTalk Failed: " + e); }
    }

    var _allButtons = [];

    function setButtonsEnabled(enabled) {
        for (var i = 0; i < _allButtons.length; i++) {
            try { _allButtons[i].enabled = enabled; } catch (e) {}
        }
    }

    function updateButtonStates() {
        var hasDoc = false;
        try { hasDoc = (app.documents.length > 0); } catch (e) {}
        setButtonsEnabled(hasDoc);
    }

    function safeRunScript(relPath, btn, originalLabel) {
        if (!isAllowedScript(relPath)) {
            alert("Security Alert: '" + relPath + "' not in allow-list.");
            return;
        }
        var file = new File(CONFIG.scriptsFolderPath + relPath);
        if (!file.exists) { alert("Script file missing:\n" + file.fsName); return; }
        if (!isWithinScriptsFolder(file)) { alert("Security: path outside scripts folder."); return; }

        if (app.documents.length === 0) {
            alert("No Illustrator document is open.\nPlease open a file first.");
            return;
        }

        // Loading indicator — show "..." while script runs
        try { btn.text = "..."; } catch (e) {}
        setButtonsEnabled(false);

        try {
            $.evalFile(file);
        } catch (e) {
            launchViaBT(file);
        }

        // Restore button state
        try { btn.text = originalLabel; } catch (e) {}
        setButtonsEnabled(true);
        updateButtonStates();
    }

    /* =========================================================
       UI
    ========================================================= */
    function createWindow() {
        if (!validateConfiguration()) return;

        if ($.global.magicFixWin instanceof Window) {
            try { $.global.magicFixWin.close(); } catch (e) {}
            $.global.magicFixWin = null;
        }

        var win = new Window("palette", CONFIG.panel.title, undefined, { closeButton: false });
        win.margins = [12, 10, 20, 12];  // [top, left, right, bottom] — extra right margin after last button

        try {
            win.graphics.backgroundColor = win.graphics.newBrush(
                win.graphics.BrushType.SOLID_COLOR, CONFIG.colors.darkBg
            );
        } catch (e) {}

        var mainRow = win.add("group");
        mainRow.orientation = "row";
        mainRow.spacing     = 18;

        // ── LOGO COLUMN ──────────────────────────────────────
        var logoGroup = mainRow.add("group");
        logoGroup.orientation   = "column";
        logoGroup.alignChildren = "center";
        logoGroup.spacing       = 8;

        var logoFile = File(CONFIG.scriptsFolderPath + CONFIG.logo.file);
        var logoLoaded = false;
        if (logoFile.exists) {
            // Only attempt image load for PNG/JPG — ScriptUI does not support SVG
            var ext = CONFIG.logo.file.toLowerCase().replace(/.*\./, "");
            if (ext === "png" || ext === "jpg" || ext === "jpeg") {
                try {
                    var img = logoGroup.add("image", undefined, logoFile);
                    img.size = [CONFIG.logo.width, CONFIG.logo.height];
                    logoLoaded = true;
                } catch (e) { logoLoaded = false; }
            }
        }
        if (!logoLoaded) {
            // Styled text logo — always works regardless of file format
            var lt1 = logoGroup.add("statictext", undefined, "Auto");
            var lt2 = logoGroup.add("statictext", undefined, "Perfect");
            try {
                var wPen = win.graphics.newPen(win.graphics.PenType.SOLID_COLOR, CONFIG.colors.white, 1);
                var vPen = win.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0.77, 0.71, 0.99, 1], 1);
                lt1.graphics.foregroundColor = wPen;
                lt1.graphics.font = ScriptUI.newFont("Helvetica", "BOLD", 18);
                lt2.graphics.foregroundColor = vPen;
                lt2.graphics.font = ScriptUI.newFont("Helvetica", "Regular", 18);
            } catch (e) {}
        }

        var credit = logoGroup.add("statictext", undefined, "Developed for OUS");
        try {
            credit.graphics.foregroundColor = win.graphics.newPen(
                win.graphics.PenType.SOLID_COLOR, CONFIG.colors.dimWhite, 1
            );
            credit.graphics.font = ScriptUI.newFont("Helvetica", "Regular", 9);
        } catch (e) {}

        // ── SEPARATOR after logo ─────────────────────────────
        var sep = mainRow.add("panel");
        sep.minimumSize = [1, 72];
        sep.maximumSize = [1, 72];
        try {
            sep.graphics.backgroundColor = sep.graphics.newBrush(
                sep.graphics.BrushType.SOLID_COLOR, [1, 1, 1, 0.2]
            );
        } catch (e) {}

        // ── BUTTONS ──────────────────────────────────────────
        // Equal spacing: fixed gapX between columns + fixed col width
        var btnPanel = mainRow.add("group");
        btnPanel.spacing       = CONFIG.button.gapX;
        btnPanel.alignChildren = ["left", "top"];

        _allButtons = [];

        for (var i = 0; i < ITEMS.length; i++) {
            (function (item) {
                var col = btnPanel.add("group");
                col.orientation    = "column";
                col.spacing        = 3;
                col.alignChildren  = "center";
                col.preferredSize  = [64, -1]; // fixed width wider than any label
                col.minimumSize    = [64, -1]; // hard minimum so labels never push it wider

                var btn = col.add("button", undefined, item.abbrev);
                btn.size    = [CONFIG.button.size.w, CONFIG.button.size.h];
                btn.helpTip = "Run: " + item.label;

                btn.onClick = (function (path, b, label) {
                    return function () { safeRunScript(path, b, label); };
                })(item.file, btn, item.abbrev);

                _allButtons.push(btn);

                // Two-line label — line1 above, line2 below
                var lbl1 = col.add("statictext", undefined, item.line1);
                var lbl2 = col.add("statictext", undefined, item.line2);
                try {
                    var wPen = win.graphics.newPen(win.graphics.PenType.SOLID_COLOR, CONFIG.colors.white, 1);
                    lbl1.graphics.foregroundColor = wPen;
                    lbl2.graphics.foregroundColor = wPen;
                    var fnt = ScriptUI.newFont("Helvetica", "Regular", 8);
                    lbl1.graphics.font = fnt;
                    lbl2.graphics.font = fnt;
                } catch (e) {}

            })(ITEMS[i]);
        }

        // Initial button state
        updateButtonStates();

        // Show first so the window has a measured size
        win.show();

        // Reposition to bottom-left after show() gives us real dimensions
        try {
            var margin = 60;
            var winW   = win.size.width;
            var winH   = win.size.height;
            // $.screen gives the primary screen rect in ExtendScript
            var scrW   = $.screen ? $.screen[2] : 220;
            var scrH   = $.screen ? $.screen[3] : 1300;
            win.location = [margin, scrH - winH - margin - 40]; // 40 = macOS dock buffer
        } catch (e) {
            // Fallback — just leave wherever it opened
        }
        $.global.magicFixWin = win;
    }

    createWindow();

})();
